# Gumroad Listing — DNA.md Branding System

---

## PRODUCT NAME
DNA.md — The Brand Identity Standard for Small Businesses & AI Workflows

---

## TAGLINE
One document. Every AI tool. Always on-brand.

---

## SHORT DESCRIPTION (shown under product name)
A complete brand identity system for small businesses, consultants, and anyone using AI to create content. Fill out the questionnaires, compile your DNA.md file, and hand it to any AI tool — once. Never explain your brand from scratch again.

---

## FULL DESCRIPTION

### Stop re-explaining your brand every time you open a new AI tool.

Every time you sit down with ChatGPT, Claude, or any other AI assistant, you start from scratch. You explain your tone. You describe your audience. You clarify what you do and don't say. Then you do it again next session.

DNA.md fixes that.

---

### What Is DNA.md?

DNA.md is a structured brand identity document — one file that captures everything an AI agent, designer, copywriter, or contractor needs to know about your brand before they create anything.

It's not a logo kit. It's not a mood board. It's the complete picture:

- Your colors, fonts, and visual style
- Your brand voice, tone, and personality
- Who your customers are and what they actually care about
- How you're positioned in the market
- What you say, what you never say, and why
- Your sales context and objection responses
- Your content pillars and channel strategy
- Your goals, your KPIs, and your constraints

One document. Total brand clarity.

---

### What's Included

**The Standard**
The full DNA.md schema — a structured template covering 12 brand domains. Use it to document any business, in any industry.

**8 Intake Questionnaires**
Short, conversational questionnaires that break the process into manageable pieces. Each one takes 10–20 minutes. No marketing background required. Perfect for walking a client through brand discovery.

**The Compiler Script**
A simple Python script that takes your 8 completed questionnaires and compiles them into a finished DNA.md file automatically.

**3 Sample Completed Files**
See exactly what a finished DNA.md looks like across three completely different businesses:
- A DTC specialty coffee subscription brand
- A handmade soy candle brand with a TikTok following
- A remote bookkeeping firm serving small business owners

All samples available in both Markdown (.md) and Word (.docx) formats.

**Plain-English Guides**
- How to use your DNA.md with any AI tool
- How to work with the files in Google Docs
- Folder structure and file management guide
- How to use DNA.md with AI agents and platforms

---

### How It Works

**1. Fill out the questionnaires**
Answer 8 short questionnaires covering every aspect of your brand. Works in any text editor, Google Docs, or Notion.

**2. Run the compiler**
One command generates your complete DNA.md file from your answers.

**3. Give it to your AI**
Paste your DNA.md into any AI tool with the included master prompt. Your AI now knows your brand — permanently (in tools that support memory) or for the session.

**4. Create confidently**
Every blog post, caption, email, and sales page your AI generates will be grounded in your actual brand — not a generic approximation of it.

---

### Works with Every Major AI Platform

| Platform | How to Use |
|---|---|
| Claude | Upload to a Project — permanent brand memory |
| ChatGPT | Custom Instructions + file upload |
| Gemini | Create a Gem with your DNA.md attached |
| Viktor (Slack) | Share in your channel — stored automatically |
| Perplexity | Spaces with custom instructions |
| Any AI | Paste the master prompt + your DNA.md |

---

### Who This Is For

- **Small business owners** who use AI to create content and are tired of inconsistent output
- **Consultants and agencies** who need a professional, repeatable client onboarding process
- **Freelancers** who want a standardized brand briefing format
- **AI power users** who want their tools to produce on-brand work without constant correction

---

### Who This Is NOT For

- Businesses looking for a logo or visual identity design service (this is a documentation standard, not a design service)
- Anyone who doesn't use AI tools in their workflow (you'll get value, but the AI integration is the real power)

---

### FAQ

**Do I need to know how to code?**
No. The compiler script is one command you copy and paste. The guides walk you through everything.

**What format are the files in?**
Markdown (.md) and Word (.docx). Both open in Google Docs, Word, Notion, or any text editor.

**Can I use this for client work?**
Yes. The license is MIT — free to use, adapt, and distribute for personal and commercial use.

**How is this different from a brand guidelines PDF?**
Brand guidelines are designed for humans to read. DNA.md is designed for AI tools to consume — structured, machine-readable, and optimized for the way AI processes context. It works for humans too, but the AI integration is the whole point.

---

### License
MIT — free for personal and commercial use.

---

## PRICE SUGGESTIONS
- **Free / Pay What You Want** — great for initial launch, building audience, getting feedback
- **$9** — low barrier, impulse purchase, good for volume
- **$19** — positioned as a professional tool, still accessible
- **$29** — if bundled with a guide or video walkthrough in the future

*Recommendation: launch at $0 (pay what you want, minimum $0) to build downloads and reviews fast. Raise to $9–$19 once you have social proof.*

---

## TAGS (for Gumroad search)
branding, brand identity, AI tools, small business, marketing, brand strategy, ChatGPT, Claude, content marketing, brand guidelines, consulting, freelance, brand voice

---

## COVER IMAGE IDEAS
- Clean dark background with "DNA.md" in large type and the tagline below
- Split image: messy AI prompt on one side → clean branded output on the other
- Flat lay of a laptop + notebook with the DNA.md interface visible
