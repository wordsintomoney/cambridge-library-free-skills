# DNA.md Compiler — How To Use
*Works on any AI agent platform or your own computer.*

---

## What This Script Does

`compile-dna.py` reads your 8 completed questionnaire files and automatically
generates a finished `DNA.md` file for your client.

---

## What You Need

- Python 3 (version 3.7 or higher)
- The 8 completed questionnaire `.md` files
- The `compile-dna.py` script

Python is free and available at https://www.python.org/downloads/
Most computers already have it. Most AI agent platforms already have it too.

---

## Folder Structure

Set it up exactly like this:

```
your-folder/
  compile-dna.py
  dna-questionnaires/
    01_visual-identity.md
    02_brand-personality.md
    03_audience-positioning.md
    04_messaging.md
    05_sales-context.md
    06_content-channels.md
    07_experience-goals.md
    08_constraints-nogos.md
```

---

## How To Fill Out the Questionnaires

Open each `.md` file in any text editor (Notepad, TextEdit, VS Code, Notion, etc.)

**For checkboxes:** Change `[ ]` to `[x]` to select an option.
```
Before: - [ ] Bold and energetic
After:  - [x] Bold and energetic
```

**For short responses:** Type your answer after the question, replacing the blank line or `_______________`.
```
Before: Primary: _______________
After:  Primary: #1A1C1E
```

---

## How To Run the Script

### Option A — On an AI Agent Platform (Manus, Viktor, etc.)
Upload the folder to the platform and tell the agent:

> "Run compile-dna.py for [Client Name]"

Or more specifically:

> "Run the file compile-dna.py with the argument '[Client Name]' and save the output as DNA.md"

The agent will handle the rest.

### Option B — On Your Own Computer (Mac)
1. Open the Terminal app (search "Terminal" in Spotlight)
2. Navigate to your folder:
   ```
   cd path/to/your-folder
   ```
3. Run the script:
   ```
   python3 compile-dna.py "Client Name Here"
   ```
4. A `DNA.md` file will appear in the same folder.

### Option C — On Your Own Computer (Windows)
1. Open Command Prompt (search "cmd" in Start)
2. Navigate to your folder:
   ```
   cd path\to\your-folder
   ```
3. Run the script:
   ```
   python compile-dna.py "Client Name Here"
   ```
4. A `DNA.md` file will appear in the same folder.

---

## Output

The script generates a single `DNA.md` file containing:
- A YAML front matter block with all brand tokens
- A full markdown body with every section populated from questionnaire responses

If a question wasn't answered, that field will show "Not specified" —
you can always edit the output file manually to fill in gaps.

---

## Tips

- Run it once, review the output, edit as needed — the DNA.md file is just a text file.
- Re-run anytime the client updates their questionnaires to regenerate a fresh version.
- The client name you pass (e.g., "Acme Brand") becomes the `name:` field in the file.
- Keep one folder per client so their questionnaires don't get mixed up.

---

## Questions?

If something doesn't work, show the error message to your AI agent and ask it to fix it.
The script is plain Python with no external dependencies — nothing to install beyond Python itself.
