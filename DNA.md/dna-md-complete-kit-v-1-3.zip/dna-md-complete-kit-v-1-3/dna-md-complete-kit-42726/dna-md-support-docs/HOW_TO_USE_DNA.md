# How To Use the DNA.md System
### A plain-English guide for non-coders

---

## What is this?

This package gives you everything you need to build a complete brand identity
document — called a **DNA.md file** — for yourself or your clients.

Here's how it works in plain English:

1. You fill out 8 short questionnaires about the brand
2. You compile the answers into a finished DNA.md file (three ways to do this — pick what works for you)
3. You hand the DNA.md to any AI tool and it knows your brand

No design software. No coding knowledge required.

---

## What's included in this package

| File / Folder | What it is |
|:---|:---|
| `DNA.md` | The full DNA.md format and schema reference |
| `HOW_TO_USE.md` | This document |
| `compile-dna.py` | Optional Python compiler script |
| `dna-questionnaires/` | Folder containing the 8 questionnaires |
| `samples/` | Three completed example brands for reference |

---

## Step 1 — Fill out the questionnaires

Open each file in the `dna-questionnaires/` folder. You can use:
- Any text editor (Notepad on Windows, TextEdit on Mac)
- Google Docs (File → Open → upload the .md file)
- Notion (paste the contents in)
- Any AI chat platform

There are 8 questionnaires, each covering a different part of the brand:

1. `01_visual-identity.md` — Colors, fonts, logo
2. `02_brand-personality.md` — Tone, voice, vibe
3. `03_audience-positioning.md` — Who you serve, where you fit in the market
4. `04_messaging.md` — What you say and how you say it
5. `05_sales-context.md` — What closes deals, what kills them
6. `06_content-channels.md` — Where you show up and what you talk about
7. `07_experience-goals.md` — How clients feel, what success looks like
8. `08_constraints-nogos.md` — What the brand will never do or say

**How to answer the questions:**

For checkbox questions, put an `x` inside the brackets to select an option:
```
Before:  - [ ] Bold and energetic
After:   - [x] Bold and energetic
```

For short response questions, just type your answer where the blank line is:
```
Before:  What makes you different? _______________
After:   What makes you different? We only work with founders, not agencies.
```

You don't have to answer every single question. Answer what you know.
Leave the rest blank — you can always fill it in later.

---

## Step 2 — Compile your DNA.md file

Once your questionnaires are filled out, you have three ways to turn them into a finished DNA.md. Pick the one that works for you.

---

### Option A — Let an AI do it (easiest, no setup needed) ⭐ Recommended

This is the simplest method and works with any AI platform that supports file uploads — Claude, ChatGPT, Gemini, Manus, or any other.

**Here's all you do:**

1. Open a new chat session with your AI tool of choice
2. Upload all 8 completed questionnaire files + the `DNA.md` template file
3. Send this prompt:

> *"I've uploaded 8 completed brand questionnaires and a DNA.md template. Please read all of the questionnaire files, extract my answers, and compile them into a complete, filled-out DNA.md file based on the template. When you're done, give me the finished file to download."*

The AI reads your answers, maps them to the right sections of the template, and hands you back a complete DNA.md. The whole thing takes under a minute.

**Why this works:** Most AI platforms allow up to 10 file uploads per session — more than enough for 8 questionnaires + the template. The AI handles all the formatting and structure automatically.

---

### Option B — Use an AI agent with the Python script

If you use an AI agent platform like Manus or Viktor that can run scripts, upload your filled-out questionnaire folder and tell the agent:

> *"I have a Python script called compile-dna.py and a folder called dna-questionnaires with 8 completed .md files. Run the script for [brand name] and generate a DNA.md file."*

Replace `[brand name]` with the actual brand name, like "Acme Coffee Co."

The agent handles everything. Your DNA.md file will be ready in seconds.

---

### Option C — Run the Python script yourself

For technical users who prefer to run it locally.

You'll need Python installed first — it's free at https://www.python.org/downloads/

**On a Mac:**
1. Open Terminal (press `Cmd + Space`, type "Terminal", hit Enter)
2. Navigate to your folder:
   ```
   cd Desktop/dna-package
   ```
3. Run the script:
   ```
   python3 compile-dna.py "Brand Name"
   ```

**On a Windows PC:**
1. Open Command Prompt (press the Windows key, type "cmd", hit Enter)
2. Navigate to your folder:
   ```
   cd Desktop\dna-package
   ```
3. Run the script:
   ```
   python compile-dna.py "Brand Name"
   ```

A `DNA.md` file will appear in your folder within seconds.

---

## Step 3 — Review and edit your DNA.md

Open the generated `DNA.md` file in any text editor, Google Docs, or AI tool.

Read through it, fill in anything that says "Not specified," and edit any section that needs more nuance. Think of the output as a strong first draft — refine it into the final deliverable.

When it feels right, it's done.

---

## FAQ

**Do I have to answer every question?**
No. Answer what you know. Blank answers will show as "Not specified" in the output and you can fill them in by editing the DNA.md file directly afterward.

**Can I run it multiple times?**
Yes. Every time you compile, it overwrites the previous DNA.md with a fresh version. If your client updates their questionnaires, just compile again.

**Can I edit the questionnaires to add my own questions?**
Yes — but if using the Python script, keep the format consistent. The script reads answers by question number (Q1, Q2, etc.), so don't change the numbering. The AI method (Option A) is more flexible and handles custom formats easily.

**What if something goes wrong with the script?**
Copy the error message and paste it into any AI agent. They'll fix it. The script has no external dependencies — nothing to install beyond Python itself — so errors are almost always something simple.

**How many files can I upload to an AI chat?**
Most platforms support 5–10 file uploads per session. Eight questionnaires + the DNA.md template = 9 files, which fits within most limits.

---

## One folder per client

Keep things organized by duplicating the questionnaire folder for each client:

```
clients/
  acme-coffee-co/
    dna-questionnaires/   ← their completed questionnaires
    DNA.md                ← their finished brand document
  northstar-studio/
    dna-questionnaires/
    DNA.md
```

This way nothing ever gets mixed up.

---

*DNA.md is an open standard. Free to use and share.*
