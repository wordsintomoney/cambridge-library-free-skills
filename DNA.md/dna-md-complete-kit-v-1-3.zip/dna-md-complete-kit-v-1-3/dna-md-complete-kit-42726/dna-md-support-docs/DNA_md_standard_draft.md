# DNA.md Standard — Draft v0.2

---

## What is DNA.md?

DNA.md is a format standard for capturing the complete brand identity of a business. It serves as the single source of truth for everything a brand is, says, looks like, and stands for — readable by both humans and AI.

Where design systems tell you *how something looks*, DNA.md tells you *what something is*. Every piece of content, every campaign, every interaction can be checked against it.

---

## Relationship to DESIGN.md

DNA.md is designed as a companion to Google's DESIGN.md format, not a replacement for it. The two specs cover different territory:

- **DESIGN.md** defines the visual layer: colors, typography, spacing, components.
- **DNA.md** defines the identity layer: voice, audience, positioning, messaging, sales context, no-gos.

When both files are present in a project, the following rule applies:

> **DESIGN.md is authoritative for visual tokens.** When DESIGN.md is present alongside DNA.md, treat the `colors`, `typography`, `spacing`, and `rounded` sections of DNA.md as **descriptive context only** — useful for rationale and prose explanation, but not normative. DESIGN.md wins on conflict for any visual token.

This lets the two files compose cleanly: agents reading both get a complete picture without ambiguity about which file owns which decision.

When DESIGN.md is **not** present, DNA.md's visual identity section is normative on its own.

---

## File Structure

A DNA.md file has two layers:

1. **YAML front matter** — Machine-readable brand tokens, delimited by `---` fences at the top of the file.
2. **Markdown body** — Human-readable brand rationale, organized into `##` sections.

The tokens are the normative values. The prose provides context, nuance, and guidance for how to apply them.

### Core vs. Extended Sections

DNA.md organizes its tokens into two tiers, marked inline within the YAML front matter using comment markers:

- **Core** — Identity essentials that almost every agent task needs: visual identity, voice, audience, positioning, messaging, no-gos.
- **Extended** — Situational depth that matters for some tasks but not all: sales context, content guidelines, customer experience, goals & KPIs, competitive landscape.

Agents handling routine tasks (a social post, a landing page, a tagline rewrite) can stop reading at the `# === END CORE ===` marker. Agents handling sales scripts, channel strategy, or KPI-driven campaigns should read the full file.

The markers are **inert YAML comments** — they have no effect on parsing, but signal section priority to any agent that knows to look for them.

---

## Token Schema (YAML Front Matter)

```yaml
version: "1.0"                    # The DNA.md spec version this file conforms to
name: <string>                    # Brand name (REQUIRED)
description: <string>             # One-line brand description
created: <date>                   # YYYY-MM-DD
updated: <date>                   # YYYY-MM-DD

# === CORE ===

# --- VISUAL IDENTITY ---
# (Descriptive only when DESIGN.md is present. Normative otherwise.)
colors:
  primary: <hex>
  secondary: <hex>
  accent: <hex>
  neutral: <hex>
  background: <hex>
  surface: <hex>
  on-primary: <hex>               # Text color on primary bg
  on-secondary: <hex>
  error: <hex>
  success: <hex>

typography:
  display:
    fontFamily: <string>
    fontSize: <dimension>
    fontWeight: <number>
    lineHeight: <number>
    letterSpacing: <dimension>
  heading:
    fontFamily: <string>
    fontSize: <dimension>
    fontWeight: <number>
  body:
    fontFamily: <string>
    fontSize: <dimension>
    fontWeight: <number>
    lineHeight: <number>
  label:
    fontFamily: <string>
    fontSize: <dimension>
    fontWeight: <number>
  caption:
    fontFamily: <string>
    fontSize: <dimension>

spacing:
  xs: <dimension>
  sm: <dimension>
  md: <dimension>
  lg: <dimension>
  xl: <dimension>

rounded:
  sm: <dimension>
  md: <dimension>
  lg: <dimension>
  full: <dimension>

logo:
  primary_url: <url>
  dark_url: <url>
  light_url: <url>
  icon_url: <url>
  minimum_size: <dimension>
  clear_space: <dimension>

# --- BRAND PERSONALITY ---
personality:
  archetypes: [<string>]          # See "Allowed Values" below
  adjectives: [<string>]          # e.g. ["bold", "warm", "direct"]
  tone: <string>                  # e.g. "confident but approachable"
  voice_style: <string>           # e.g. "conversational", "authoritative"
  formality: <low|medium|high>    # Enum: only these three values

# --- BRAND STORY ---
story:
  founded: <year>
  mission: <string>
  vision: <string>
  values: [<string>]
  tagline: <string>
  origin_summary: <string>

# --- TARGET AUDIENCE ---
audience:
  primary:
    name: <string>                # e.g. "The Ambitious Founder"
    age_range: <string>
    gender: <string>
    income: <string>
    education: <string>
    location: <string>
    psychographics: [<string>]
    pain_points: [<string>]
    goals: [<string>]
  secondary:
    name: <string>
    description: <string>
  not_for: [<string>]             # Who this brand explicitly does NOT serve

# --- MARKET POSITIONING ---
positioning:
  category: <string>              # What space/market they're in
  subcategory: <string>
  tier: <premium|mid|value>       # Enum: only these three values
  differentiation: <string>       # What makes them different in one sentence
  perception_goal: <string>       # How they want to be perceived
  against: [<string>]             # What they position against (concepts, not just competitors)

# --- MESSAGING ---
messaging:
  elevator_pitch: <string>        # 1-2 sentences, what they do and for whom
  headline: <string>              # Primary marketing headline
  subheadline: <string>
  value_propositions: [<string>]  # Top 3-5 value props
  proof_points: [<string>]        # Evidence/credibility builders
  calls_to_action:
    primary: <string>
    secondary: <string>
  messaging_hierarchy:
    - level: 1
      message: <string>
    - level: 2
      message: <string>
    - level: 3
      message: <string>

# --- CONSTRAINTS & NO-GOS ---
constraints:
  never_say: [<string>]           # Words/phrases that are off-brand
  never_do: [<string>]            # Actions/associations to avoid
  never_look_like: [<string>]     # Visual/aesthetic directions to avoid
  legal_restrictions: [<string>]  # Any compliance or legal guardrails
  sensitive_topics: [<string>]    # Topics to handle with care or avoid

# === END CORE ===

# === EXTENDED ===

# --- COMPETITIVE LANDSCAPE ---
competitors:
  - name: <string>
    url: <url>
    relationship: <direct|indirect|aspirational>
    how_different: <string>
    do_not_become: <boolean>      # true = this is a cautionary example

  avoid_comparison_to: [<string>] # Brands/concepts they don't want to be compared to

# --- SALES CONTEXT ---
sales:
  avg_deal_size: <string>
  sales_cycle: <string>           # e.g. "2-4 weeks"
  primary_channel: <string>       # e.g. "referral", "inbound", "outbound"
  deal_breakers: [<string>]       # What kills a deal
  objections:
    - objection: <string>
      response: <string>
  closers: [<string>]             # What consistently closes deals
  red_flags: [<string>]           # Prospect signals that mean bad fit

# --- CONTENT GUIDELINES ---
content:
  pillars: [<string>]             # Core content topics they own
  formats: [<string>]             # e.g. ["short-form video", "long-form blog"]
  channels:
    - platform: <string>
      purpose: <string>
      frequency: <string>
      tone_modifier: <string>     # How tone shifts on this platform
  topics_to_avoid: [<string>]
  hashtags: [<string>]
  keywords: [<string>]

# --- CUSTOMER EXPERIENCE ---
experience:
  feeling_goal: <string>          # How every interaction should feel
  service_standards: [<string>]
  touchpoints:
    - name: <string>
      description: <string>
      tone: <string>
  onboarding_summary: <string>
  retention_strategy: <string>

# --- GOALS & KPIS ---
goals:
  current_priorities: [<string>]
  kpis:
    - metric: <string>
      target: <string>
      timeframe: <string>
  growth_stage: <startup|growth|scale|mature>   # Enum: only these four values
  horizon: <string>               # e.g. "12-month focus"

# === END EXTENDED ===
```

---

## Allowed Values (Enums)

Fields marked as enums must use one of the listed values. Linters should flag values outside these lists.

| Field | Allowed values |
|:------|:---------------|
| `personality.formality` | `low`, `medium`, `high` |
| `positioning.tier` | `premium`, `mid`, `value` |
| `goals.growth_stage` | `startup`, `growth`, `scale`, `mature` |
| `competitors[].relationship` | `direct`, `indirect`, `aspirational` |

### `personality.archetypes`

Archetypes use the standard 12-archetype framework derived from Jungian brand archetypes. Allowed values:

`Innocent`, `Sage`, `Explorer`, `Outlaw`, `Magician`, `Hero`, `Lover`, `Jester`, `Everyman`, `Caregiver`, `Creator`, `Ruler`

A brand may declare 1–2 archetypes (a primary, optionally a secondary). Values outside this list are accepted with a warning for forward compatibility, but linters should flag them.

---

## Section Order (Markdown Body)

Sections use `##` headings. They can be omitted, but those present must appear in this order:

| # | Section | Tier | Purpose |
|:--|:--------|:-----|:--------|
| 1 | Overview | Core | The brand at a glance — who they are, what they do, why they exist |
| 2 | Brand Story | Core | Origin, mission, vision, values, founding narrative |
| 3 | Visual Identity | Core | Colors, type, logo, spacing — with rationale for each choice |
| 4 | Brand Personality | Core | Voice, tone, adjectives, archetypes — how the brand *feels* |
| 5 | Target Audience | Core | Who they serve, who they don't, deep audience insight |
| 6 | Market Positioning | Core | Where they sit, how they differentiate, how they want to be perceived |
| 7 | Messaging | Core | Headlines, value props, proof points, CTAs, messaging hierarchy |
| 8 | Constraints & No-Gos | Core | What the brand will never do, say, or be associated with |
| 9 | Competitive Landscape | Extended | Key competitors, how to stand apart, what not to become |
| 10 | Sales Context | Extended | Objections, closers, deal-breakers, red flags, sales cycle |
| 11 | Content Guidelines | Extended | Pillars, channels, formats, topics to own and avoid |
| 12 | Customer Experience | Extended | How interactions should feel, service standards, touchpoints |
| 13 | Goals & KPIs | Extended | What success looks like right now, key metrics, current priorities |

Note: section order has been updated in v0.2 to group Core sections first, followed by Extended sections. Files written under v0.1 may have a different order; linters should accept v0.1 ordering when `version: "1.0"` is declared.

---

## Rules

1. The YAML front matter is **normative** — tokens defined here are the authoritative values, except for visual tokens when DESIGN.md is present (see "Relationship to DESIGN.md").
2. The markdown body is **explanatory** — it provides context, rationale, and nuance.
3. When conflict exists between front matter and prose, **front matter wins**.
4. All sections are **optional** but must appear in canonical order when present.
5. Token references use `{section.token}` syntax (e.g., `{colors.primary}`, `{messaging.tagline}`).
6. Duplicate section headings are **invalid**.
7. Unknown fields in front matter are **accepted with a warning** — forward compatibility.
8. The `name` field in front matter is **required**.
9. Enum fields must use one of the allowed values listed in "Allowed Values" above.
10. The `# === CORE ===` / `# === END CORE ===` and `# === EXTENDED ===` / `# === END EXTENDED ===` markers are **inert YAML comments**. They have no effect on parsing. They exist as agent hints only.

---

## Validation Rules (Linting)

| Rule | Severity | What it checks |
|:-----|:---------|:---------------|
| `missing-name` | error | The `name` field is absent from front matter |
| `broken-ref` | error | Token references (`{section.token}`) that don't resolve |
| `invalid-enum` | error | Enum field uses a value outside its allowed list |
| `missing-mission` | warning | Brand story section exists but no mission defined |
| `missing-audience` | warning | No primary audience defined |
| `missing-differentiator` | warning | Positioning exists but no differentiation statement |
| `contrast-ratio` | warning | Color pairs in visual identity below WCAG AA (4.5:1) |
| `orphaned-colors` | warning | Colors defined but never referenced in components or prose |
| `missing-value-props` | warning | Messaging section exists but no value propositions |
| `unknown-archetype` | warning | An archetype value outside the standard 12-archetype list |
| `no-gos-empty` | info | Constraints section is absent — recommended for all brands |
| `section-order` | warning | Sections appear out of canonical order |
| `core-marker-missing` | info | Core/Extended marker comments absent (recommended for v0.2+ files) |
| `token-summary` | info | Count of tokens defined per section |

---

## Example (Minimal)

```markdown
---
version: "1.0"
name: Meridian & Co.
description: Premium B2B consulting for scaling founders

# === CORE ===

colors:
  primary: "#0D1B2A"
  secondary: "#E8C547"
  neutral: "#F4F1EC"

personality:
  archetypes: ["Sage"]
  adjectives: ["sharp", "grounded", "direct"]
  tone: "authoritative but human"
  formality: medium

story:
  mission: "Help ambitious founders build companies worth owning."
  values: ["clarity", "ownership", "results"]
  tagline: "Built to Last."

positioning:
  tier: premium
  differentiation: "Strategy that actually ships."

messaging:
  elevator_pitch: "We help scaling founders cut through complexity and build systems that last."
  value_propositions:
    - "Clarity over chaos"
    - "Strategy that ships"
    - "A partner, not a vendor"

constraints:
  never_say: ["synergy", "circle back", "low-hanging fruit"]
  never_do: ["templated playbooks", "junior-led engagements"]

# === END CORE ===
---

## Overview

Meridian & Co. is a premium consulting firm for founders who have found product-market fit and are ready to scale without losing what made them great.

## Brand Personality

Sharp, grounded, and direct. We don't dress things up. We tell founders what's true, what matters, and what to do about it. The tone is that of a trusted advisor who's seen it all — confident, never arrogant.

## Messaging

The core message is simple: **clarity creates momentum**. Most founders are drowning in options. Meridian cuts through the noise and builds the path forward.
```

---

## Status

DNA.md is at version `1.0` of the spec, draft `v0.2`. The format is under active development.

### Changelog

**v0.2 (current)**
- Added "Relationship to DESIGN.md" section with soft interoperability rule
- Introduced Core / Extended section tiers via inline YAML comment markers
- Tightened enum constraints on `formality`, `tier`, `growth_stage`, `relationship`
- Added standard 12-archetype list for `personality.archetypes`
- Reordered canonical sections: Core sections first, Extended sections after
- Added linter rules: `invalid-enum`, `unknown-archetype`, `core-marker-missing`

**v0.1**
- Initial draft

---

*Created by Cambridge. Not affiliated with Google or the DESIGN.md project.*
