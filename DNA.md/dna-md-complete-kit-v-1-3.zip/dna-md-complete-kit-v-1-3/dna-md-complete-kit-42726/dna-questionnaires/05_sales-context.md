# DNA.md Questionnaire — 05: Sales Context
*Complete this section to capture what drives and blocks sales for your brand.*

---

## Sales Basics

**Q1. What is your average deal or transaction size?**
- [ ] Under $100
- [ ] $100–$500
- [ ] $500–$2,000
- [ ] $2,000–$10,000
- [ ] $10,000–$50,000
- [ ] $50,000+
- [ ] Varies widely

**Q2. How long is your typical sales cycle?**
- [ ] Instant / same day
- [ ] A few days
- [ ] 1–2 weeks
- [ ] 2–4 weeks
- [ ] 1–3 months
- [ ] 3+ months

**Q3. How do most of your clients find you? (pick top 2)**
- [ ] Referrals / word of mouth
- [ ] Social media
- [ ] Google / search
- [ ] Outbound outreach (cold email, DMs)
- [ ] Partnerships
- [ ] Events / networking
- [ ] Paid ads
- [ ] Other: _______________

**Q4. Where does the sale usually happen?**
- [ ] Discovery/sales call
- [ ] In-person meeting
- [ ] Online checkout (no call needed)
- [ ] Proposal + follow-up
- [ ] Demo or trial
- [ ] Other: _______________

---

## Objections

**Q5. What's the most common reason a prospect doesn't buy? (pick top 3)**
- [ ] Price — it's too expensive
- [ ] Timing — not ready right now
- [ ] Trust — they don't know us well enough
- [ ] DIY — they think they can do it themselves
- [ ] Competitor — they go with someone else
- [ ] Decision maker — they need to check with someone else
- [ ] Unclear ROI — they're not sure it's worth it
- [ ] Other: _______________

**Q6. How do you typically handle the price objection? (short response)**
_______________

---

## What Closes Deals

**Q7. What most consistently gets a prospect to say yes? (pick all that apply)**
- [ ] A strong testimonial or case study
- [ ] A clear ROI or outcome example
- [ ] A limited-time offer or urgency
- [ ] A free consultation or audit
- [ ] Social proof (reviews, press, follower count)
- [ ] A clear, simple proposal
- [ ] Personal rapport / relationship
- [ ] A guarantee or risk reversal
- [ ] Other: _______________

**Q8. What's your best closer in one sentence?**
_______________

---

## Red Flags & Deal-Breakers

**Q9. What are signs that a prospect is a bad fit? (pick all that apply)**
- [ ] They're only focused on getting the lowest price
- [ ] They've worked with many providers and keep switching
- [ ] They want results but aren't willing to put in the work
- [ ] They have unrealistic timeline expectations
- [ ] They don't respect boundaries or your process
- [ ] They're vague about their goals or budget
- [ ] They want to micromanage everything
- [ ] Other: _______________

**Q10. Is there a type of client you will never work with again?**
- [ ] No
- [ ] Yes: _______________

---

## Post-Sale

**Q11. What happens right after a client signs? (short response)**
_______________

**Q12. What's your #1 source of repeat business or upsells?**
_______________

---
*Section 5 of 8 — Next: Content & Channels*
