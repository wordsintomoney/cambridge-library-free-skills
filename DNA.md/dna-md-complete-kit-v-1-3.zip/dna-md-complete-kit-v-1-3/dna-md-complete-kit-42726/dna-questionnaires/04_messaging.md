# DNA.md Questionnaire — 04: Messaging
*Complete this section to define what your brand says and how it says it.*

---

## Core Message

**Q1. In one sentence, what does your brand do and for whom?**
_______________

**Q2. What's your current tagline or slogan? (leave blank if none)**
_______________

**Q3. If you had to describe your brand in 3 words, what would they be?**
1. _______________
2. _______________
3. _______________

---

## Value Propositions

**Q4. What are the top reasons a customer should choose you over anyone else? (pick all that apply)**
- [ ] We're faster than the competition
- [ ] We're more affordable
- [ ] We have more experience / expertise
- [ ] We offer a more personalized experience
- [ ] We have proven results / track record
- [ ] We're easier to work with
- [ ] We offer something nobody else does
- [ ] We specialize in a specific niche
- [ ] Other: _______________

**Q5. What's your single strongest value proposition? (short response)**
_______________

---

## Proof Points

**Q6. What evidence backs up your claims? (pick all that apply)**
- [ ] Years in business: _______________
- [ ] Number of clients served: _______________
- [ ] Specific results/outcomes: _______________
- [ ] Awards or recognition: _______________
- [ ] Testimonials / case studies
- [ ] Media features or press
- [ ] Certifications or credentials
- [ ] Other: _______________

---

## Headlines & CTAs

**Q7. What's the main headline you'd put on your website homepage?**
_______________

**Q8. What's your primary call to action? (what do you want people to do first?)**
- [ ] Book a call
- [ ] Get a free quote
- [ ] Sign up / create an account
- [ ] Buy now
- [ ] Download a resource
- [ ] Contact us
- [ ] Other: _______________

**Q9. What's your secondary call to action?**
- [ ] Learn more
- [ ] See our work
- [ ] Read the blog
- [ ] Follow us on social
- [ ] Subscribe to our newsletter
- [ ] Other: _______________

---

## Messaging Hierarchy

**Q10. Rank these in order of importance for your brand message (1 = most important):**
- ___ What we do
- ___ Who we do it for
- ___ Why we're different
- ___ How we do it
- ___ The results we get

**Q11. What's the ONE thing you want someone to remember after encountering your brand?**
_______________

---

## Language Style

**Q12. Which words or phrases feel very "on-brand" for you? (list up to 5)**
_______________

**Q13. Which words or phrases feel very "off-brand"? (list up to 5)**
_______________

**Q14. Do you use profanity or very casual language in your brand voice?**
- [ ] Yes, it's part of our personality
- [ ] Occasionally, in the right context
- [ ] No, we keep it clean

---
*Section 4 of 8 — Next: Sales Context*
