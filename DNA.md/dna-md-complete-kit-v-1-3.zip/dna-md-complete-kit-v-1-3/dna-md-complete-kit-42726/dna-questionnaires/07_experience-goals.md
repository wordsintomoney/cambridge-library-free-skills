# DNA.md Questionnaire — 07: Experience & Goals
*Complete this section to define how your brand delivers and what success looks like.*

---

## Customer Experience

**Q1. How should a client feel after every interaction with your brand?**
- [ ] Confident and clear
- [ ] Inspired and energized
- [ ] Supported and cared for
- [ ] Impressed and delighted
- [ ] Informed and empowered
- [ ] Relieved (like a weight was lifted)
- [ ] Other: _______________

**Q2. What word best describes your client experience standard?**
- [ ] Seamless
- [ ] Personal
- [ ] Fast
- [ ] Premium
- [ ] Thorough
- [ ] Warm
- [ ] Efficient
- [ ] Other: _______________

**Q3. What's your response time standard for client communication?**
- [ ] Same day
- [ ] Within 24 hours
- [ ] Within 48 hours
- [ ] Within a week
- [ ] No formal standard

**Q4. What's one thing clients consistently compliment about working with you?**
_______________

**Q5. What's one thing you know you could improve in your client experience?**
_______________

---

## Onboarding

**Q6. Do you have a formal client onboarding process?**
- [ ] Yes, it's well-defined
- [ ] Somewhat — it's inconsistent
- [ ] No, it's ad hoc

**Q7. What does your onboarding include? (pick all that apply)**
- [ ] Welcome email or packet
- [ ] Kickoff call
- [ ] Contract / agreement
- [ ] Intake questionnaire
- [ ] Access to a portal or tool
- [ ] Introduction to the team
- [ ] Timeline / project roadmap
- [ ] Other: _______________

---

## Retention & Loyalty

**Q8. What keeps clients coming back? (pick top 2)**
- [ ] Consistent results
- [ ] Strong personal relationship
- [ ] Ongoing value / content
- [ ] Loyalty perks or discounts
- [ ] They're locked in (contract, subscription)
- [ ] Community / belonging
- [ ] Other: _______________

**Q9. Do you have a referral program?**
- [ ] Yes
- [ ] No, but I want one
- [ ] No, referrals happen organically

---

## Business Goals

**Q10. What growth stage is your business in right now?**
- [ ] Just starting out (0–1 years)
- [ ] Early traction (1–3 years)
- [ ] Growing steadily (3–5 years)
- [ ] Scaling (5+ years, expanding)
- [ ] Established / mature

**Q11. What are your top 3 business priorities RIGHT NOW?**
1. _______________
2. _______________
3. _______________

**Q12. What does success look like for your brand in the next 12 months?**
_______________

---

## KPIs

**Q13. Which metrics matter most to your brand? (pick up to 4)**
- [ ] Revenue / sales
- [ ] Number of new clients
- [ ] Client retention rate
- [ ] Social media followers / reach
- [ ] Website traffic
- [ ] Email list size
- [ ] Conversion rate
- [ ] Average deal size
- [ ] Net Promoter Score (NPS)
- [ ] Other: _______________

**Q14. Do you currently track these metrics regularly?**
- [ ] Yes, consistently
- [ ] Sometimes
- [ ] Not really

---
*Section 7 of 8 — Next: Constraints & No-Gos*
