# DNA.md Questionnaire — 02: Brand Personality
*Complete this section to define how your brand sounds and feels.*

---

## Tone & Voice

**Q1. If your brand were a person, how would they talk?**
- [ ] Straight to the point, no fluff
- [ ] Warm and conversational, like a friend
- [ ] Professional and polished
- [ ] Witty and a little funny
- [ ] Inspirational and motivating
- [ ] Educational and informative
- [ ] Bold and provocative
- [ ] Calm and reassuring

**Q2. How formal is your brand's communication?**
- [ ] Very formal (corporate, boardroom)
- [ ] Somewhat formal (professional but approachable)
- [ ] Neutral (depends on the context)
- [ ] Casual (relaxed, everyday language)
- [ ] Very casual (slang, emojis, conversational)

**Q3. Does your brand use humor?**
- [ ] Yes, regularly
- [ ] Occasionally, when appropriate
- [ ] Rarely
- [ ] Never — we keep it serious

**Q4. Does your brand use industry jargon?**
- [ ] Yes, our audience expects it
- [ ] Sometimes, but we explain it
- [ ] No, we keep language simple and accessible

---

## Personality Adjectives

**Q5. Pick up to 5 words that describe your brand's personality:**
- [ ] Bold
- [ ] Trustworthy
- [ ] Innovative
- [ ] Grounded
- [ ] Ambitious
- [ ] Nurturing
- [ ] Disruptive
- [ ] Reliable
- [ ] Empowering
- [ ] Elegant
- [ ] Edgy
- [ ] Authentic
- [ ] Energetic
- [ ] Calm
- [ ] Sharp
- [ ] Playful
- [ ] Authoritative
- [ ] Approachable
- [ ] Other: _______________

**Q6. Pick up to 2 words your brand is definitely NOT:**
- [ ] Boring
- [ ] Aggressive
- [ ] Salesy
- [ ] Cold
- [ ] Arrogant
- [ ] Chaotic
- [ ] Timid
- [ ] Stiff
- [ ] Trendy (chasing trends)
- [ ] Other: _______________

---

## Brand Archetype

**Q7. Which of these characters feels most like your brand? (pick 1-2)**
- [ ] The Hero — inspires action, overcomes challenges, wins
- [ ] The Sage — shares knowledge, educates, builds wisdom
- [ ] The Creator — innovative, expressive, builds new things
- [ ] The Caregiver — nurturing, protective, serves others
- [ ] The Ruler — authoritative, premium, commands respect
- [ ] The Rebel — challenges the norm, disrupts, breaks rules
- [ ] The Explorer — adventurous, free-spirited, independent
- [ ] The Everyman — relatable, down-to-earth, inclusive
- [ ] The Magician — transformative, visionary, makes things happen
- [ ] The Jester — fun, lighthearted, entertains
- [ ] The Lover — passionate, intimate, emotionally connected
- [ ] The Innocent — optimistic, pure, simple

---

## Brand in Context

**Q8. Complete this sentence: "When someone interacts with our brand, we want them to feel ___"**
_______________

**Q9. If your brand were a celebrity or public figure (real or fictional), who would it be?**
_______________

**Q10. What's one brand (any industry) whose personality you admire and why?**
_______________

---
*Section 2 of 8 — Next: Audience & Positioning*
