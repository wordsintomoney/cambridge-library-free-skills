# DNA.md Questionnaire — 08: Constraints & No-Gos
*Complete this section to define what your brand will never do, say, or be.*

---

## Language Constraints

**Q1. Are there specific words or phrases your brand will NEVER use?**
(e.g. "cheap," "guru," "hustle," "synergy")
_______________

**Q2. Are there phrases that feel fake or inauthentic to your brand?**
- [ ] "We're a family"
- [ ] "Crushing it"
- [ ] "Game-changer"
- [ ] "Ninja / Rockstar / Guru"
- [ ] "Authentic" (used ironically)
- [ ] "Disruptive"
- [ ] "World-class"
- [ ] Other: _______________

**Q3. Does your brand avoid any specific communication style?**
- [ ] Aggressive or pushy sales language
- [ ] Fear-based messaging
- [ ] Overpromising / hype
- [ ] Passive or wishy-washy language
- [ ] Corporate jargon / buzzwords
- [ ] Other: _______________

---

## Visual Constraints

**Q4. Are there visual styles your brand will never use?**
- [ ] Clip art or stock photo clichés
- [ ] Overly busy / cluttered layouts
- [ ] Neon colors
- [ ] Comic sans or novelty fonts
- [ ] Dated / retro aesthetics (unintentional)
- [ ] Other: _______________

**Q5. Are there brands whose visual style you never want to be compared to?**
_______________

---

## Association Constraints

**Q6. Are there topics, causes, or conversations your brand stays out of publicly?**
- [ ] Politics
- [ ] Religion
- [ ] Social justice issues
- [ ] Competitor disputes
- [ ] Controversial trends
- [ ] Other: _______________

**Q7. Are there types of clients, industries, or partnerships your brand will not pursue?**
_______________

**Q8. Are there brands, people, or organizations you will not publicly associate with?**
_______________

---

## Ethical & Legal Constraints

**Q9. Does your brand have any legal restrictions on what it can say or claim?**
- [ ] Yes: _______________
- [ ] No
- [ ] Not sure

**Q10. Are there any regulated terms your industry requires you to be careful with?**
(e.g. "results may vary," "not financial advice," etc.)
- [ ] Yes: _______________
- [ ] No

**Q11. Does your brand have a policy on endorsements or testimonials?**
- [ ] Yes, we have a formal policy
- [ ] Informal / common sense approach
- [ ] No policy yet

---

## The Bottom Line

**Q12. Complete this sentence: "Our brand will NEVER ___"**
_______________

**Q13. Complete this sentence: "If someone described us as ___, we'd be embarrassed."**
_______________

**Q14. Is there anything else about what your brand stands against that we haven't covered?**
_______________

---
*Section 8 of 8 — You're done! Your responses will be used to generate your DNA.md file.*

---

## What Happens Next

Your completed questionnaires will be reviewed and compiled into a single **DNA.md** file — the complete genetic code of your brand. This file can be shared with AI tools, designers, copywriters, and collaborators so everyone produces work that's authentically, consistently you.
