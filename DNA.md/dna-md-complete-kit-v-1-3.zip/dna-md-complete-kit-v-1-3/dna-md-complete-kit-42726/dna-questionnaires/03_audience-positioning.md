# DNA.md Questionnaire — 03: Audience & Positioning
*Complete this section to define who you serve and where you stand in the market.*

---

## Primary Audience

**Q1. Who is your ideal customer? (pick the best fit)**
- [ ] Individual consumers (B2C)
- [ ] Small business owners
- [ ] Mid-size business decision makers
- [ ] Enterprise / corporate buyers
- [ ] Nonprofits / mission-driven orgs
- [ ] Government / public sector
- [ ] Mix of the above: _______________

**Q2. What is the age range of your primary audience?**
- [ ] 18–24
- [ ] 25–34
- [ ] 35–44
- [ ] 45–54
- [ ] 55–64
- [ ] 65+
- [ ] All ages

**Q3. What is the income level of your primary audience?**
- [ ] Budget-conscious (price is the priority)
- [ ] Middle income (value for money matters)
- [ ] Upper-middle income (quality over price)
- [ ] High income (premium, price is not a barrier)

**Q4. Where does your primary audience spend time online? (pick all that apply)**
- [ ] Instagram
- [ ] LinkedIn
- [ ] TikTok
- [ ] Facebook
- [ ] YouTube
- [ ] X (Twitter)
- [ ] Podcasts
- [ ] Email newsletters
- [ ] Google Search
- [ ] Other: _______________

**Q5. What are the top 3 pain points your audience has that you solve?**
1. _______________
2. _______________
3. _______________

**Q6. What does your audience want MORE than anything?**
_______________

---

## Who You're NOT For

**Q7. Who is your brand NOT a good fit for? (pick all that apply)**
- [ ] People looking for the cheapest option
- [ ] People who want a quick fix with no commitment
- [ ] Large corporations (we focus on small/mid)
- [ ] People who aren't ready to invest in their growth
- [ ] A specific industry: _______________
- [ ] Other: _______________

---

## Market Positioning

**Q8. What category/industry are you in?**
_______________

**Q9. Where do you sit in the market?**
- [ ] Premium / luxury tier (top of market)
- [ ] Mid-market (quality at a fair price)
- [ ] Value / accessible (affordable, volume-focused)

**Q10. What makes you different from everyone else in your space? (short response)**
_______________

**Q11. How do you want to be perceived in your market?**
- [ ] The premium, go-to expert
- [ ] The innovative disruptor
- [ ] The trusted, reliable partner
- [ ] The accessible, everyone's-welcome option
- [ ] The niche specialist
- [ ] Other: _______________

**Q12. What do you NOT want to be known as?**
_______________

---

## Secondary Audience

**Q13. Do you have a secondary audience (influencers, partners, referral sources)?**
- [ ] Yes
- [ ] No

**Q14. If yes, briefly describe them:**
_______________

---
*Section 3 of 8 — Next: Messaging*
