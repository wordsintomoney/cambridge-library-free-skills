# DNA.md Questionnaire — 06: Content & Channels
*Complete this section to define where your brand shows up and what it talks about.*

---

## Content Pillars

**Q1. What topics does your brand own? (pick up to 5)**
- [ ] Industry education / how-to content
- [ ] Behind the scenes / brand story
- [ ] Client results / case studies
- [ ] Thought leadership / opinions
- [ ] Product or service spotlights
- [ ] Community / culture content
- [ ] News and trends in your space
- [ ] Personal brand / founder story
- [ ] Entertainment / humor
- [ ] Other: _______________

**Q2. What topics do you actively avoid? (pick all that apply)**
- [ ] Politics
- [ ] Religion
- [ ] Competitor callouts
- [ ] Controversial social issues
- [ ] Pricing (don't post publicly)
- [ ] Personal life
- [ ] Other: _______________

---

## Active Channels

**Q3. Where is your brand currently active? (pick all that apply)**
- [ ] Instagram
- [ ] LinkedIn
- [ ] TikTok
- [ ] Facebook
- [ ] YouTube
- [ ] X (Twitter)
- [ ] Pinterest
- [ ] Podcast
- [ ] Blog / website
- [ ] Email newsletter
- [ ] Other: _______________

**Q4. Where do you get the BEST results right now?**
_______________

**Q5. Where do you WANT to grow but haven't yet?**
_______________

---

## Content Format

**Q6. What content formats does your brand use? (pick all that apply)**
- [ ] Short-form video (Reels, TikToks, Shorts)
- [ ] Long-form video (YouTube)
- [ ] Static image posts
- [ ] Carousels / slideshows
- [ ] Long-form written (blog, LinkedIn articles)
- [ ] Short written (captions, tweets, posts)
- [ ] Email newsletters
- [ ] Podcasts / audio
- [ ] Webinars / live video
- [ ] Infographics
- [ ] Other: _______________

**Q7. How often do you currently post content?**
- [ ] Daily
- [ ] A few times a week
- [ ] Weekly
- [ ] A few times a month
- [ ] Rarely / inconsistently

**Q8. How often do you WANT to post?**
- [ ] Daily
- [ ] A few times a week
- [ ] Weekly
- [ ] A few times a month

---

## Channel-Specific Tone

**Q9. Does your tone change depending on the platform?**
- [ ] Yes — I'm more casual on some, professional on others
- [ ] No — I keep the same tone everywhere
- [ ] Not sure / haven't thought about it

**Q10. If yes, describe how your tone shifts by platform (short response):**
Instagram: _______________
LinkedIn: _______________
TikTok: _______________
Email: _______________
Other: _______________

---

## SEO & Keywords

**Q11. Are there specific keywords or phrases your brand wants to be found for?**
_______________

**Q12. Do you have a hashtag strategy?**
- [ ] Yes — list your top hashtags: _______________
- [ ] No, not yet
- [ ] We don't use hashtags

---
*Section 6 of 8 — Next: Experience & Goals*
