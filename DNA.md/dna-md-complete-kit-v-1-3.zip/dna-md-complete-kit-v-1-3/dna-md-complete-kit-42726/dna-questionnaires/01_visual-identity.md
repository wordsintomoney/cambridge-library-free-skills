# DNA.md Questionnaire — 01: Visual Identity
*Complete this section to define how your brand looks.*

---

## Colors

**Q1. Do you already have brand colors?**
- [ ] Yes, I have exact hex codes
- [ ] Yes, but I'm not sure of the exact codes
- [ ] No, I need help choosing them

**Q2. If yes, list your brand colors below (hex codes or descriptions):**
Primary: _______________
Secondary: _______________
Accent: _______________
Background: _______________

**Q3. What feeling should your color palette give off?**
- [ ] Bold and energetic
- [ ] Calm and trustworthy
- [ ] Luxurious and premium
- [ ] Warm and approachable
- [ ] Clean and minimal
- [ ] Dark and edgy
- [ ] Bright and playful
- [ ] Other: _______________

**Q4. Which color palettes do you like? (pick all that apply)**
- [ ] Deep, dark tones (navy, black, forest green)
- [ ] Earthy neutrals (cream, tan, terracotta)
- [ ] Bright, saturated colors (electric blue, hot pink, lime)
- [ ] Muted, desaturated tones (sage, dusty rose, slate)
- [ ] Classic black and white with one accent
- [ ] Pastels (soft lavender, blush, mint)

**Q5. Are there any colors you absolutely do NOT want in your brand?**
_______________

---

## Typography

**Q6. Do you have brand fonts?**
- [ ] Yes
- [ ] No
- [ ] Not sure

**Q7. If yes, list them here:**
Heading font: _______________
Body font: _______________

**Q8. What kind of type style fits your brand?**
- [ ] Serif (traditional, editorial — think NYT or Vogue)
- [ ] Sans-serif (modern, clean — think Apple or Google)
- [ ] Slab serif (bold, industrial — think bold headlines)
- [ ] Script/handwritten (personal, creative)
- [ ] Monospace (technical, precise)
- [ ] Mixed (two contrasting fonts)

**Q9. How should your text feel overall?**
- [ ] Large and commanding
- [ ] Small and refined
- [ ] Balanced and readable
- [ ] Expressive and varied

---

## Logo

**Q10. Do you have a logo?**
- [ ] Yes, finalized
- [ ] Yes, but it needs work
- [ ] No

**Q11. What style is your logo (or what style do you want)?**
- [ ] Wordmark (just the brand name in a styled font)
- [ ] Lettermark (initials only)
- [ ] Icon + wordmark
- [ ] Abstract symbol
- [ ] Emblem / badge
- [ ] Not sure

**Q12. Does your logo work on both light and dark backgrounds?**
- [ ] Yes
- [ ] Only on light
- [ ] Only on dark
- [ ] Not sure / N/A

---

## Overall Visual Vibe

**Q13. Pick 3 words that describe how your brand should LOOK:**
- [ ] Sleek
- [ ] Raw
- [ ] Elegant
- [ ] Rugged
- [ ] Playful
- [ ] Sophisticated
- [ ] Minimal
- [ ] Maximalist
- [ ] Retro
- [ ] Futuristic
- [ ] Organic
- [ ] Geometric
- [ ] Other: _______________

**Q14. Are there any brands whose visual identity you admire? (doesn't have to be your industry)**
_______________

**Q15. Are there any visual styles you want to avoid?**
_______________

---
*Section 1 of 8 — Next: Brand Personality*
