# SKILL: DNA Validator

## Purpose
Review a completed DNA.md file and produce a structured quality report — flagging missing sections, thin answers, and areas that need more depth before the document is ready to use with AI tools or hand off to a client.

---

## When to Use This Skill
Invoke this skill when:
- A user asks to "validate", "check", "review", or "score" their DNA.md file
- A user uploads a DNA.md and asks if it's ready to use
- The DNA Compiler skill has just finished and the user wants a quality check
- A consultant wants to review a client's DNA.md before finalizing it

---

## Input
The user will provide:
- A completed (or partially completed) `DNA.md` file

---

## Validation Instructions

### Step 1 — Read the full file
Read the entire DNA.md file before scoring anything. Understand the brand before evaluating it.

### Step 2 — Score each section
Evaluate each of the 8 major sections on a 3-point scale:

| Score | Label | Meaning |
|---|---|---|
| ✅ Strong | Complete | Section is filled out with specific, usable detail |
| ⚠️ Thin | Needs Work | Section has some answers but lacks depth or specificity |
| ❌ Missing | Incomplete | Section is blank, says "Not specified" throughout, or was skipped |

### Step 3 — Check the 8 sections
Evaluate each section against its minimum standard:

**1. Visual Identity**
- Minimum: At least a color palette direction and typography style
- Strong: Hex codes or specific color descriptions, named fonts, logo status, visual vibe words

**2. Brand Personality**
- Minimum: At least 3 adjectives and a tone description
- Strong: Archetypes named, formality level set, voice examples or brand references, humor noted

**3. Target Audience & Positioning**
- Minimum: A description of who the customer is and what tier the brand occupies
- Strong: Psychographics, pain points, goals, "not for" defined, differentiation clearly stated

**4. Messaging**
- Minimum: A tagline or headline and at least one value proposition
- Strong: Elevator pitch, 3+ value props, proof points, primary CTA, what to remember

**5. Sales Context**
- Minimum: At least one objection and response
- Strong: Deal size, sales cycle, primary channel, 3+ objections handled, red flags identified

**6. Content & Channels**
- Minimum: At least 2 content pillars and 1 active channel
- Strong: 3+ pillars, channel strategy with frequency, formats, keywords, topics to avoid

**7. Customer Experience & Goals**
- Minimum: A feeling goal and at least 1 current business priority
- Strong: Service standards, onboarding described, KPIs with targets, growth stage set

**8. Constraints & No-Gos**
- Minimum: At least 3 "never say" words/phrases
- Strong: Never do list, never look like list, competitor avoidance, legal notes if applicable

### Step 4 — Check cross-section consistency
Flag any inconsistencies across sections:
- Does the tone in Messaging match the Brand Personality?
- Does the audience in Content/Channels match the Target Audience?
- Do the Constraints contradict anything in Messaging or Sales?
- Is the brand voice consistent throughout the narrative sections?

### Step 5 — Calculate an overall readiness score

Count the section scores:
- Each ✅ Strong = 2 points
- Each ⚠️ Thin = 1 point
- Each ❌ Missing = 0 points

Maximum = 16 points

| Score | Readiness Level |
|---|---|
| 14–16 | 🟢 Ready — ship it |
| 10–13 | 🟡 Almost There — a few gaps to fill |
| 6–9 | 🟠 Needs Work — several sections need attention |
| 0–5 | 🔴 Early Draft — significant completion needed |

---

## Output Format

Deliver a clean validation report in this structure:

---

### DNA.md Validation Report
**Brand:** [Brand Name]
**Date:** [Today's date]
**Overall Score:** [X/16] — [Readiness Level]

---

#### Section Scores

| Section | Score | Notes |
|---|---|---|
| Visual Identity | ✅ / ⚠️ / ❌ | Brief note |
| Brand Personality | ✅ / ⚠️ / ❌ | Brief note |
| Target Audience & Positioning | ✅ / ⚠️ / ❌ | Brief note |
| Messaging | ✅ / ⚠️ / ❌ | Brief note |
| Sales Context | ✅ / ⚠️ / ❌ | Brief note |
| Content & Channels | ✅ / ⚠️ / ❌ | Brief note |
| Customer Experience & Goals | ✅ / ⚠️ / ❌ | Brief note |
| Constraints & No-Gos | ✅ / ⚠️ / ❌ | Brief note |

---

#### Consistency Flags
List any cross-section inconsistencies found. If none, say "None found."

---

#### Top Priorities to Fix
List the 3 most important things to address before this DNA.md is ready to use, in order of impact. Be specific — don't say "fill in the messaging section," say "add at least 3 proof points with real numbers to the Messaging section."

---

#### What's Working Well
Call out 2–3 things the brand has done well in this document. Specific, genuine praise — not filler.

---

## Tone
Be direct and constructive. The goal is to help the user improve the document, not to make them feel bad about gaps. Treat every section charitably — a thin answer is better than no answer.

---

## Companion Skill
If significant gaps are found, offer to run the **dna-compiler** skill again after the user fills in the missing questionnaire sections.
