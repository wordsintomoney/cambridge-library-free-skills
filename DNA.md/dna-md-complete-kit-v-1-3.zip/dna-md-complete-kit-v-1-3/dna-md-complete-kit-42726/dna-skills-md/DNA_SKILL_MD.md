# SKILL: DNA Compiler

## Purpose
Compile a complete, filled-out DNA.md brand identity document from a set of completed questionnaire files. This skill replaces the need for any Python script — the agent IS the compiler.

---

## When to Use This Skill
Invoke this skill when:
- A user provides 1–8 completed DNA.md questionnaire files
- A user says "compile my DNA", "build my DNA.md", "generate my brand document", or similar
- A user uploads questionnaire files and asks for a finished brand identity document

---

## Input
The user will provide some or all of the following files (completed with their answers):
- `01_visual-identity.md`
- `02_brand-personality.md`
- `03_audience-positioning.md`
- `04_messaging.md`
- `05_sales-context.md`
- `06_content-channels.md`
- `07_experience-goals.md`
- `08_constraints-nogos.md`

They may also provide:
- The blank `DNA.md` template as a structural reference
- A brand name to use in the output

---

## Compilation Instructions

### Step 1 — Read everything first
Read ALL uploaded questionnaire files in full before writing anything. Do not begin output until you have processed every file provided.

### Step 2 — Extract answers
For each questionnaire, extract:
- All checked checkboxes (marked with `[x]`)
- All filled-in text fields (lines with content after the blank or colon)
- Any free-text answers written below questions
- Ignore any unchecked boxes `[ ]` and blank fields

### Step 3 — Map answers to DNA.md sections
Use the mapping below to place extracted answers into the correct DNA.md sections:

| Questionnaire | DNA.md Section |
|---|---|
| 01_visual-identity | Visual Identity (colors, typography, logo, visual vibe) |
| 02_brand-personality | Brand Personality (archetypes, adjectives, tone, voice, formality) |
| 03_audience-positioning | Target Audience + Market Positioning |
| 04_messaging | Messaging (tagline, headline, value props, CTAs, proof points) |
| 05_sales-context | Sales Context (deal size, cycle, objections, closers, red flags) |
| 06_content-channels | Content Guidelines (pillars, channels, formats, keywords) |
| 07_experience-goals | Customer Experience + Goals & KPIs |
| 08_constraints-nogos | Constraints & No-Gos (never say, never do, never look like) |

### Step 4 — Handle missing answers gracefully
- If a field was left blank or unchecked: write `Not specified` in the YAML and omit it from the narrative prose (don't call attention to gaps)
- If only some questionnaires were provided: compile what's available, note at the top which sections are incomplete
- Never invent or fabricate answers — only use what the user provided

### Step 5 — Write the narrative sections
Below the YAML front matter, write human-readable prose for each major section. Use the completed sample files as style reference. Each narrative section should:
- Synthesize the answers into flowing, readable paragraphs
- Match the brand's stated tone and voice (from questionnaire 02)
- Be specific — use the actual words, colors, and details the user provided
- Sound like it was written for that brand, not copied from a template

### Step 6 — Set the metadata
In the YAML front matter, set:
- `name:` — the brand name provided by the user
- `version:` — "1.0"
- `created:` — today's date
- `updated:` — today's date
- `description:` — a one-sentence summary synthesized from the user's answers

---

## Output Format
Produce the complete DNA.md file as a single code block (` ```yaml ``` ` for the front matter, then plain markdown for the narrative). Offer the user a downloadable file when done.

---

## Style Reference
Refer to the completed sample files in this skill folder for tone, structure, and formatting examples:
- `DNA_Sample_Groundwork_Coffee.md` — DTC product brand, B2C
- `DNA_Sample_WickAndWild.md` — handmade goods, social-first brand
- `DNA_Sample_LedgerAndLeaf.md` — service business, B2B

Match the depth and specificity of these samples in your output.

---

## Quality Checks Before Delivering
Before handing the file to the user, verify:
- [ ] All 8 DNA.md sections are present (even if some say "Not specified")
- [ ] YAML front matter is valid and properly closed with `---`
- [ ] Brand name appears correctly throughout
- [ ] No fabricated answers — every claim traces back to a questionnaire response
- [ ] Narrative prose is written in the brand's voice, not generic template language
- [ ] File is offered as a download

---

## Companion Skill
After compiling, offer to run the **dna-validator** skill to check the output for completeness and quality.
