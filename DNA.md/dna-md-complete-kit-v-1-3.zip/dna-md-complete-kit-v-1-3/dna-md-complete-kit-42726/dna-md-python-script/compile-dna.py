#!/usr/bin/env python3
"""
DNA.md Compiler — v0.2.1
Reads completed questionnaire files and generates a DNA.md file
conforming to the DNA.md spec v0.2.

Changes from v0.1:
- YAML output is now safely escaped (handles quotes, colons, apostrophes)
- Adds Core / Extended marker comments to YAML front matter
- Reorders sections to match v0.2 canonical order (Core first, Extended after)

Patches in v0.2.1:
- Missing questionnaire files no longer crash the script (return "" not {})
- Empty short-responses no longer produce empty bullet points
- first_or() now treats whitespace-only items as missing
- Checkbox regex anchored to line boundaries to avoid stray mid-line matches
- Multi-line answers now preserve lines containing [, #, or *
- All file reads/writes now use UTF-8 encoding (Windows compatibility)
- Empty CLI arguments fall back to "Unknown Brand"
- Friendly error message instead of Python traceback on file-write failure
- Removed three unused legacy parser functions to prevent future confusion
"""

import os
import sys
import re
from datetime import date

_arg = sys.argv[1].strip() if len(sys.argv) > 1 else ""
client_name = _arg if _arg else "Unknown Brand"
q_dir = "dna-questionnaires"
output_file = "DNA.md"

def read_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def parse_questionnaire(filepath):
    if not os.path.exists(filepath):
        return ""
    try:
        return read_file(filepath)
    except (IOError, OSError, UnicodeDecodeError) as e:
        print(f"⚠️  Warning: Could not read {filepath}: {e}")
        return ""

# Read all questionnaires
q1 = parse_questionnaire(f"{q_dir}/01_visual-identity.md")
q2 = parse_questionnaire(f"{q_dir}/02_brand-personality.md")
q3 = parse_questionnaire(f"{q_dir}/03_audience-positioning.md")
q4 = parse_questionnaire(f"{q_dir}/04_messaging.md")
q5 = parse_questionnaire(f"{q_dir}/05_sales-context.md")
q6 = parse_questionnaire(f"{q_dir}/06_content-channels.md")
q7 = parse_questionnaire(f"{q_dir}/07_experience-goals.md")
q8 = parse_questionnaire(f"{q_dir}/08_constraints-nogos.md")

def find_response(text, q_number):
    """Find a short-response answer by Q number.

    Captures every non-blank line after the question header up to the next
    blank line, the next **Q...** marker, or the next section heading.
    Skips placeholder underscores and checkbox lines.
    """
    pattern = rf'\*\*Q{q_number}[^*]*\*\*[ \t]*\r?\n'
    match = re.search(pattern, text)
    if not match:
        return ""
    after = text[match.end():]
    answer_lines = []
    for raw in after.split('\n'):
        line = raw.strip()
        if not line:
            break  # blank line ends the answer
        if line.startswith('**Q') or line.startswith('## ') or line.startswith('# '):
            break  # next question or section
        if re.match(r'^[-*]?\s*\[[ xX]\]', line):
            continue  # skip checkbox lines (handled by find_checked)
        if set(line) <= {'_', ' ', '\t'}:
            continue  # skip placeholder underscores
        answer_lines.append(line)
    return ' '.join(answer_lines)

def find_checked(text, q_number):
    """Find all checked boxes for a Q number."""
    pattern = rf'\*\*Q{q_number}[^*]*\*\*'
    parts = re.split(pattern, text, maxsplit=1)
    if len(parts) < 2:
        return []
    block = parts[1].split('\n\n')[0]
    items = re.findall(r'^\s*[-*]?\s*\[x\]\s*(.+?)\s*$', block, re.IGNORECASE | re.MULTILINE)
    return [i.strip() for i in items if i.strip()]

# ── Extract key values ──────────────────────────────────────────────────────

# Visual Identity
colors_feeling    = find_checked(q1, 3)
color_palettes    = find_checked(q1, 4)
no_colors         = find_response(q1, 5)
font_style        = find_checked(q1, 8)
logo_style        = find_checked(q1, 11)
visual_words      = find_checked(q1, 13)
admired_visuals   = find_response(q1, 14)
avoid_visuals     = find_response(q1, 15)

# Brand Personality
talk_style        = find_checked(q2, 1)
formality         = find_checked(q2, 2)
humor             = find_checked(q2, 3)
adjectives        = find_checked(q2, 5)
not_adjectives    = find_checked(q2, 6)
archetypes        = find_checked(q2, 7)
feeling_goal      = find_response(q2, 8)
brand_celeb       = find_response(q2, 9)
admired_brand     = find_response(q2, 10)

# Audience & Positioning
customer_type     = find_checked(q3, 1)
age_range         = find_checked(q3, 2)
income            = find_checked(q3, 3)
online_channels   = find_checked(q3, 4)
_pain             = find_response(q3, 5)
pain_points       = [_pain] if _pain else []
audience_want     = find_response(q3, 6)
not_for           = find_checked(q3, 7)
industry          = find_response(q3, 8)
market_tier       = find_checked(q3, 9)
differentiation   = find_response(q3, 10)
perception_goal   = find_checked(q3, 11)
not_known_as      = find_response(q3, 12)

# Messaging
elevator_pitch    = find_response(q4, 1)
tagline           = find_response(q4, 2)
_three            = find_response(q4, 3)
three_words       = [_three] if _three else []
value_props       = find_checked(q4, 4)
top_value_prop    = find_response(q4, 5)
proof_points      = find_checked(q4, 6)
headline          = find_response(q4, 7)
primary_cta       = find_checked(q4, 8)
secondary_cta     = find_checked(q4, 9)
remember_one      = find_response(q4, 11)
on_brand_words    = find_response(q4, 12)
off_brand_words   = find_response(q4, 13)

# Sales Context
deal_size         = find_checked(q5, 1)
sales_cycle       = find_checked(q5, 2)
lead_sources      = find_checked(q5, 3)
sale_location     = find_checked(q5, 4)
objections        = find_checked(q5, 5)
price_objection   = find_response(q5, 6)
closers           = find_checked(q5, 7)
best_closer       = find_response(q5, 8)
red_flags         = find_checked(q5, 9)
never_again       = find_response(q5, 10)

# Content & Channels
content_pillars   = find_checked(q6, 1)
topics_avoid      = find_checked(q6, 2)
active_channels   = find_checked(q6, 3)
best_channel      = find_response(q6, 4)
growth_channel    = find_response(q6, 5)
formats           = find_checked(q6, 6)
post_frequency    = find_checked(q6, 7)
keywords          = find_response(q6, 11)
hashtags          = find_response(q6, 12)

# Experience & Goals
cx_feeling        = find_checked(q7, 1)
cx_standard       = find_checked(q7, 2)
response_time     = find_checked(q7, 3)
cx_compliment     = find_response(q7, 4)
cx_improve        = find_response(q7, 5)
onboarding_items  = find_checked(q7, 7)
retention         = find_checked(q7, 8)
growth_stage      = find_checked(q7, 10)
priorities        = find_response(q7, 11)
success_12mo      = find_response(q7, 12)
kpis              = find_checked(q7, 13)

# Constraints
never_say         = find_response(q8, 1)
fake_phrases      = find_checked(q8, 2)
avoid_style       = find_checked(q8, 3)
visual_never      = find_checked(q8, 4)
never_compared    = find_response(q8, 5)
stay_out_of       = find_checked(q8, 6)
no_clients        = find_response(q8, 7)
no_associations   = find_response(q8, 8)
legal             = find_response(q8, 9)
never_sentence    = find_response(q8, 12)
embarrassed       = find_response(q8, 13)

# ── Format helpers ──────────────────────────────────────────────────────────

def yaml_escape(value):
    """Safely escape a string for YAML double-quoted output.

    Handles: backslashes, double quotes, control chars, leading/trailing
    whitespace. Returns the value wrapped in double quotes, ready to
    drop into a YAML document.
    """
    if value is None:
        return '""'
    s = str(value)
    # Escape backslashes first, then double quotes
    s = s.replace('\\', '\\\\').replace('"', '\\"')
    # Replace literal newlines/tabs with their YAML escape sequences
    s = s.replace('\n', '\\n').replace('\r', '\\r').replace('\t', '\\t')
    return f'"{s}"'

def yaml_list(items, indent=2):
    """Emit a YAML list with each string item safely escaped."""
    if not items:
        return "[]"
    pad = " " * indent
    return "\n" + "\n".join(f"{pad}- {yaml_escape(i)}" for i in items)

def yaml_str(value, fallback="Not specified"):
    """Emit a single safely-escaped YAML string, falling back when empty."""
    if value is None or value == "":
        return yaml_escape(fallback)
    return yaml_escape(value)

def first_or(items, fallback="Not specified"):
    """Return first non-empty item from a list, or a fallback string."""
    if items and str(items[0]).strip():
        return items[0]
    return fallback

def md_list(items):
    if not items:
        return "_Not specified_"
    return "\n".join(f"- {i}" for i in items)

today = date.today().isoformat()

# ── Build DNA.md ────────────────────────────────────────────────────────────

output = f"""---
version: "1.0"
name: {yaml_escape(client_name)}
description: {yaml_str(elevator_pitch, fallback="Brand description not provided")}
created: "{today}"
updated: "{today}"

# === CORE ===

# VISUAL IDENTITY
# (When DESIGN.md is present, treat this section as descriptive only — DESIGN.md wins on visual tokens.)
colors:
  feeling: {yaml_list(colors_feeling)}
  palette_direction: {yaml_list(color_palettes)}
  avoid: {yaml_str(no_colors, fallback="")}

typography:
  style: {yaml_list(font_style)}

logo:
  style: {yaml_list(logo_style)}

visual_vibe: {yaml_list(visual_words)}
visual_admire: {yaml_str(admired_visuals, fallback="")}
visual_avoid: {yaml_str(avoid_visuals, fallback="")}

# BRAND PERSONALITY
personality:
  archetypes: {yaml_list(archetypes)}
  adjectives: {yaml_list(adjectives)}
  not_adjectives: {yaml_list(not_adjectives)}
  talk_style: {yaml_list(talk_style)}
  formality: {yaml_escape(first_or(formality))}
  humor: {yaml_escape(first_or(humor))}
  feeling_goal: {yaml_str(feeling_goal, fallback="")}
  brand_reference: {yaml_str(brand_celeb, fallback="")}

# AUDIENCE & POSITIONING
audience:
  customer_type: {yaml_list(customer_type)}
  age_range: {yaml_list(age_range)}
  income: {yaml_escape(first_or(income))}
  online_channels: {yaml_list(online_channels)}
  primary_want: {yaml_str(audience_want, fallback="")}
  not_for: {yaml_list(not_for)}

positioning:
  industry: {yaml_str(industry, fallback="")}
  tier: {yaml_escape(first_or(market_tier))}
  differentiation: {yaml_str(differentiation, fallback="")}
  perception_goal: {yaml_escape(first_or(perception_goal))}
  not_known_as: {yaml_str(not_known_as, fallback="")}

# MESSAGING
messaging:
  elevator_pitch: {yaml_str(elevator_pitch, fallback="")}
  tagline: {yaml_str(tagline, fallback="")}
  headline: {yaml_str(headline, fallback="")}
  top_value_proposition: {yaml_str(top_value_prop, fallback="")}
  value_propositions: {yaml_list(value_props)}
  proof_points: {yaml_list(proof_points)}
  primary_cta: {yaml_escape(first_or(primary_cta))}
  secondary_cta: {yaml_escape(first_or(secondary_cta))}
  remember_one_thing: {yaml_str(remember_one, fallback="")}
  on_brand_words: {yaml_str(on_brand_words, fallback="")}
  off_brand_words: {yaml_str(off_brand_words, fallback="")}

# CONSTRAINTS & NO-GOS
constraints:
  never_say: {yaml_str(never_say, fallback="")}
  fake_phrases_to_avoid: {yaml_list(fake_phrases)}
  communication_style_avoid: {yaml_list(avoid_style)}
  visual_never: {yaml_list(visual_never)}
  never_compared_to: {yaml_str(never_compared, fallback="")}
  stay_out_of: {yaml_list(stay_out_of)}
  no_client_types: {yaml_str(no_clients, fallback="")}
  no_associations: {yaml_str(no_associations, fallback="")}
  legal_restrictions: {yaml_str(legal, fallback="")}
  never_sentence: {yaml_str(never_sentence, fallback="")}
  embarrassed_by: {yaml_str(embarrassed, fallback="")}

# === END CORE ===

# === EXTENDED ===

# SALES CONTEXT
sales:
  avg_deal_size: {yaml_escape(first_or(deal_size))}
  sales_cycle: {yaml_escape(first_or(sales_cycle))}
  primary_channels: {yaml_list(lead_sources)}
  common_objections: {yaml_list(objections)}
  price_objection_response: {yaml_str(price_objection, fallback="")}
  closers: {yaml_list(closers)}
  best_closer: {yaml_str(best_closer, fallback="")}
  red_flags: {yaml_list(red_flags)}

# CONTENT & CHANNELS
content:
  pillars: {yaml_list(content_pillars)}
  topics_to_avoid: {yaml_list(topics_avoid)}
  active_channels: {yaml_list(active_channels)}
  best_channel: {yaml_str(best_channel, fallback="")}
  growth_channel: {yaml_str(growth_channel, fallback="")}
  formats: {yaml_list(formats)}
  posting_frequency: {yaml_escape(first_or(post_frequency))}
  keywords: {yaml_str(keywords, fallback="")}
  hashtags: {yaml_str(hashtags, fallback="")}

# EXPERIENCE & GOALS
experience:
  feeling_goal: {yaml_escape(first_or(cx_feeling))}
  standard: {yaml_escape(first_or(cx_standard))}
  response_time: {yaml_escape(first_or(response_time))}
  onboarding: {yaml_list(onboarding_items)}
  retention: {yaml_list(retention)}

goals:
  growth_stage: {yaml_escape(first_or(growth_stage))}
  current_priorities: {yaml_str(priorities, fallback="")}
  success_12_months: {yaml_str(success_12mo, fallback="")}
  kpis: {yaml_list(kpis)}

# === END EXTENDED ===
---

## Overview

{elevator_pitch or f"{client_name} — brand overview not yet provided."}

{f'Tagline: **"{tagline}"**' if tagline else ''}

## Brand Story

{f'Mission: {audience_want}' if audience_want else '_Complete the audience questionnaire to populate this section._'}

## Visual Identity

{f'The visual direction should feel: **{", ".join(visual_words)}**.' if visual_words else ''}
{f'Color palette direction: {", ".join(color_palettes)}.' if color_palettes else ''}
{f'Typography style: {", ".join(font_style)}.' if font_style else ''}
{f'Visual references admired: {admired_visuals}' if admired_visuals else ''}
{f'Visual styles to avoid: {avoid_visuals}' if avoid_visuals else ''}

## Brand Personality

{f'Archetypes: {", ".join(archetypes)}.' if archetypes else ''}
{f'Personality adjectives: {", ".join(adjectives)}.' if adjectives else ''}
{f'This brand is NOT: {", ".join(not_adjectives)}.' if not_adjectives else ''}
{f'Communication style: {", ".join(talk_style)}.' if talk_style else ''}
{f'Formality level: {formality[0] if formality else "Not specified"}.' }
{f'When someone interacts with this brand, they should feel: **{feeling_goal}**.' if feeling_goal else ''}
{f'Brand reference point: {brand_celeb}.' if brand_celeb else ''}

## Target Audience

{f'Primary audience: {", ".join(customer_type)}.' if customer_type else ''}
{f'Age range: {", ".join(age_range)}.' if age_range else ''}
{f'Income level: {income[0] if income else "Not specified"}.' }
{f'What they want most: {audience_want}.' if audience_want else ''}
{f'This brand is NOT for: {", ".join(not_for)}.' if not_for else ''}

## Market Positioning

{f'Industry: {industry}.' if industry else ''}
{f'Market tier: {market_tier[0] if market_tier else "Not specified"}.' }
{f'Differentiation: {differentiation}' if differentiation else ''}
{f'Perception goal: {perception_goal[0] if perception_goal else "Not specified"}.' }
{f'This brand does NOT want to be known as: {not_known_as}.' if not_known_as else ''}

## Messaging

{f'**{headline}**' if headline else ''}

{f'{elevator_pitch}' if elevator_pitch else ''}

{f'The one thing to remember: _{remember_one}_' if remember_one else ''}

Value Propositions:
{md_list(value_props)}

Proof Points:
{md_list(proof_points)}

{f'Primary CTA: **{primary_cta[0] if primary_cta else "Not specified"}**' }
{f'On-brand language: {on_brand_words}' if on_brand_words else ''}
{f'Off-brand language: {off_brand_words}' if off_brand_words else ''}

## Constraints & No-Gos

{f'This brand will never say: _{never_say}_' if never_say else ''}
{f'This brand will never: _{never_sentence}_' if never_sentence else ''}
{f"If described as this, we would be embarrassed: {embarrassed}" if embarrassed else ""}

Phrases to avoid:
{md_list(fake_phrases)}

Communication styles to avoid:
{md_list(avoid_style)}

Visual styles to avoid:
{md_list(visual_never)}

Topics we stay out of:
{md_list(stay_out_of)}

{f'Client types we do not work with: {no_clients}' if no_clients else ''}
{f'Associations to avoid: {no_associations}' if no_associations else ''}
{f'Legal/compliance notes: {legal}' if legal else ''}

## Sales Context

{f'Average deal size: {deal_size[0] if deal_size else "Not specified"}.' }
{f'Sales cycle: {sales_cycle[0] if sales_cycle else "Not specified"}.' }
{f'Primary lead sources: {", ".join(lead_sources)}.' if lead_sources else ''}

Common objections:
{md_list(objections)}

{f'Best closer: _{best_closer}_' if best_closer else ''}

Red flags (bad-fit signals):
{md_list(red_flags)}

## Content Guidelines

Content pillars:
{md_list(content_pillars)}

Active channels:
{md_list(active_channels)}

{f'Best performing channel: {best_channel}.' if best_channel else ''}
{f'Growth target channel: {growth_channel}.' if growth_channel else ''}

Topics to avoid:
{md_list(topics_avoid)}

{f'Keywords: {keywords}' if keywords else ''}
{f'Hashtags: {hashtags}' if hashtags else ''}

## Customer Experience

{f'Every interaction should make clients feel: **{cx_feeling[0] if cx_feeling else "Not specified"}**.' }
{f'Service standard: {cx_standard[0] if cx_standard else "Not specified"}.' }
{f'Response time: {response_time[0] if response_time else "Not specified"}.' }

Onboarding includes:
{md_list(onboarding_items)}

Retention drivers:
{md_list(retention)}

## Goals & KPIs

{f'Growth stage: {growth_stage[0] if growth_stage else "Not specified"}.' }
{f'Current priorities: {priorities}' if priorities else ''}
{f'12-month success looks like: {success_12mo}' if success_12mo else ''}

Key metrics:
{md_list(kpis)}
"""

try:
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(output)
except (IOError, OSError, PermissionError) as e:
    print(f"❌ Error: Could not write to {output_file}: {e}")
    print(f"   Check that you have write permission in this folder and try again.")
    sys.exit(1)

print(f"✅ DNA.md generated successfully for: {client_name}")
print(f"📄 Output saved to: {output_file}")
