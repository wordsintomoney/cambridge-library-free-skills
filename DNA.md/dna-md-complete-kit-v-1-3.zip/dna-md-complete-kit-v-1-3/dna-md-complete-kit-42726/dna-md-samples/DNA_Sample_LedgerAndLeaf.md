---
version: "1.0"
name: Ledger & Leaf Bookkeeping
description: Friendly, modern bookkeeping for small business owners who'd rather focus on their work than their numbers.
created: 2026-04-27
updated: 2026-04-27

# --- VISUAL IDENTITY ---
colors:
  primary: "#1B3A2D"
  secondary: "#4A9B72"
  accent: "#A8D5B5"
  neutral: "#F4F7F5"
  background: "#FFFFFF"
  surface: "#EBF2EE"
  on-primary: "#FFFFFF"
  on-secondary: "#FFFFFF"
  error: "#B03A2E"
  success: "#2E7D32"

typography:
  display:
    fontFamily: "Fraunces"
    fontSize: "48px"
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: "-0.5px"
  heading:
    fontFamily: "Fraunces"
    fontSize: "28px"
    fontWeight: 600
  body:
    fontFamily: "IBM Plex Sans"
    fontSize: "16px"
    fontWeight: 400
    lineHeight: 1.7
  label:
    fontFamily: "IBM Plex Sans"
    fontSize: "13px"
    fontWeight: 600
  caption:
    fontFamily: "IBM Plex Sans"
    fontSize: "12px"

spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "32px"
  xl: "64px"

rounded:
  sm: "4px"
  md: "8px"
  lg: "16px"
  full: "9999px"

logo:
  primary_url: "https://ledgerandleaf.co/assets/logo-primary.svg"
  dark_url: "https://ledgerandleaf.co/assets/logo-dark.svg"
  light_url: "https://ledgerandleaf.co/assets/logo-light.svg"
  icon_url: "https://ledgerandleaf.co/assets/icon.svg"
  minimum_size: "120px"
  clear_space: "16px"

# --- BRAND PERSONALITY ---
personality:
  archetypes: ["Caregiver", "Sage"]
  adjectives: ["calm", "trustworthy", "approachable", "clear", "warm"]
  tone: "reassuring and plain-spoken — like a smart friend who happens to know accounting"
  voice_style: "clear, jargon-free, quietly confident"
  formality: medium

# --- BRAND STORY ---
story:
  founded: 2020
  mission: "Take the financial stress off small business owners' plates so they can get back to doing work they love."
  vision: "A world where running a small business doesn't mean drowning in spreadsheets and tax anxiety."
  values: ["clarity", "reliability", "human connection", "calm", "small business advocacy"]
  tagline: "Your numbers, handled."
  origin_summary: "Ledger & Leaf was founded in 2020 by Priya Mathur, a CPA who spent eight years at a large accounting firm and kept watching small business owners get passed over for the boutique, attentive service they actually needed. She left to build something different — a bookkeeping firm that felt less like a vendor and more like a trusted partner. Starting with 4 clients out of her home office in Nashville, TN, Ledger & Leaf now serves 60+ small businesses across the US remotely."

# --- TARGET AUDIENCE ---
audience:
  primary:
    name: "The Overwhelmed Owner"
    age_range: "30–55"
    gender: "all"
    income: "$80,000–$500,000 annual business revenue"
    education: "Varied — expert in their field, not in finance"
    location: "US-based, primarily remote clients"
    psychographics:
      - "Started their business because they love what they do, not to manage finances"
      - "Feels mild to moderate anxiety about money and taxes"
      - "Has tried to DIY bookkeeping and knows it's not working"
      - "Values relationships over transactions — wants to actually know who they're working with"
      - "Busy. Does not have time for complicated onboarding or slow response times."
    pain_points:
      - "Books are a mess and tax season is a nightmare every year"
      - "Previous bookkeeper was unresponsive or hard to understand"
      - "Feels embarrassed about the state of their finances"
      - "Doesn't know if their business is actually profitable month to month"
      - "Scared to hand over financial access to someone they don't trust"
    goals:
      - "Never think about bookkeeping again — just have it handled"
      - "Understand their numbers without needing a finance degree"
      - "File taxes without panic"
      - "Know their business is healthy (or know early if it isn't)"
  secondary:
    name: "The New Business Owner"
    description: "Just launched or in year one. Wants to set things up right from the start. Lower revenue but high growth potential and strong LTV if served well early."
  not_for:
    - "Large corporations or businesses with in-house finance teams"
    - "Clients who want the absolute cheapest option — our value is service quality"
    - "Anyone who is rude or dismissive to our team"

# --- MARKET POSITIONING ---
positioning:
  category: "Bookkeeping & Accounting Services"
  subcategory: "Remote bookkeeping for small businesses"
  tier: mid
  differentiation: "We combine CPA-level expertise with the warmth and responsiveness of a trusted friend. Most bookkeepers are either too expensive and corporate or too cheap and unreliable. We're the one that actually picks up the phone."
  perception_goal: "The bookkeeper I finally trust — and actually like talking to."
  against:
    - "Impersonal, unresponsive accounting firms that treat small businesses like an afterthought"
    - "Cheap DIY software that leaves owners more confused than before"
    - "The anxiety and shame spiral that comes from ignored finances"

# --- COMPETITIVE LANDSCAPE ---
competitors:
  - name: "Bench Accounting"
    url: "https://bench.co"
    relationship: direct
    how_different: "Bench is software-first with humans in the background. We are relationship-first — your bookkeeper knows your business, your goals, and your name."
    do_not_become: false
  - name: "1-800Accountant"
    url: "https://1800accountant.com"
    relationship: direct
    how_different: "Call-center energy, high volume, low relationship. We are the opposite — intentionally small, intentionally personal."
    do_not_become: true
  - name: "Local CPA firms"
    url: ""
    relationship: indirect
    how_different: "Traditional firms often deprioritize small business clients. We built our entire model around them."
    do_not_become: false

avoid_comparison_to: ["H&R Block", "TurboTax", "big four accounting firms"]

# --- MESSAGING ---
messaging:
  elevator_pitch: "Ledger & Leaf is a remote bookkeeping firm for small business owners who want their finances handled by someone who actually knows their name. We do the books, you run the business."
  headline: "Your numbers, handled."
  subheadline: "Remote bookkeeping for small business owners who have better things to do than stare at spreadsheets."
  value_propositions:
    - "A dedicated bookkeeper who knows your business — not a rotating support queue"
    - "Monthly financials delivered clean and on time, every month"
    - "Plain-English explanations — no jargon, no confusion"
    - "Responsive communication — we actually answer within 24 hours"
    - "CPA-reviewed work — accuracy you can take to the bank (and to your tax preparer)"
  proof_points:
    - "60+ active small business clients across 14 industries"
    - "4.9 stars across all reviews — zero churn in the past 18 months"
    - "Average client has been with us 2.4 years"
    - "100% remote — serving clients across all 50 states"
    - "Founded and led by a licensed CPA with 10+ years of experience"
  calls_to_action:
    primary: "Book a Free Clarity Call"
    secondary: "See How It Works"
  messaging_hierarchy:
    - level: 1
      message: "Stop dreading your finances. We'll handle them."
    - level: 2
      message: "A dedicated bookkeeper who knows your business, delivers clean monthly reports, and actually responds when you reach out."
    - level: 3
      message: "CPA-level expertise, small-firm warmth, remote convenience. Starting at $X/month."

# --- SALES CONTEXT ---
sales:
  avg_deal_size: "$400–$900/month retainer depending on transaction volume"
  sales_cycle: "1–3 weeks — trust-based purchase, requires a conversation"
  primary_channel: "Referrals + LinkedIn + Google search"
  deal_breakers:
    - "Price sensitivity without understanding the value"
    - "Trust barrier — handing over financial access is vulnerable"
    - "Previous bad experience with a bookkeeper (requires rebuilding confidence)"
  objections:
    - objection: "I've been burned by a bookkeeper before."
      response: "That's the most common thing we hear. We built our process specifically around the things that go wrong — responsiveness, accuracy, and communication. Every new client gets a 90-day check-in to make sure it's working."
    - objection: "Can't I just use QuickBooks myself?"
      response: "You can — and many of our clients tried that first. The question isn't whether the software works. It's whether you have time to use it well. Most owners don't, and the cost of mistakes or missed deductions is almost always more than our fee."
    - objection: "How do I know you'll understand my industry?"
      response: "We serve clients across 14 industries. We match you with a bookkeeper who has relevant experience, and the onboarding is built around learning your specific business."
    - objection: "What if I need a CPA for taxes?"
      response: "We're bookkeepers, not tax preparers — but we work seamlessly with your CPA or can refer you to one we trust. We hand off clean, organized books that make tax prep faster and cheaper."
  closers:
    - "Free Clarity Call removes risk from the first step"
    - "90-day satisfaction guarantee — if it's not working, we make it right"
    - "Referrals from trusted peers are our strongest closer"
    - "Showing a sample monthly report during the sales call"
  red_flags:
    - "Wants someone to do taxes only (not our service)"
    - "Expects same-day responses on complex questions"
    - "Extremely disorganized with no willingness to participate in onboarding"
    - "Pushing hard on price before understanding scope"

# --- CONTENT GUIDELINES ---
content:
  pillars:
    - "Financial clarity for small business owners (education)"
    - "Behind the scenes of running a small business"
    - "Bookkeeping myths and common mistakes"
    - "Client success stories and transformations"
    - "Calm, practical money mindset"
  formats:
    - "Short LinkedIn posts (tips, observations, stories)"
    - "Email newsletter (biweekly)"
    - "Short-form video (Reels/TikTok — Priya's face, not a brand account)"
    - "Blog posts (SEO)"
    - "Client case studies"
  channels:
    - platform: "LinkedIn"
      purpose: "Primary B2B discovery and authority building"
      frequency: "3–4x per week"
      tone_modifier: "Professional but warm — Priya's personal voice, not corporate"
    - platform: "Instagram"
      purpose: "Brand warmth, behind-the-scenes, relatable small business content"
      frequency: "3x per week"
      tone_modifier: "More casual, more personal, less business-formal"
    - platform: "Email"
      purpose: "Nurture, education, trust-building with leads and clients"
      frequency: "Biweekly"
      tone_modifier: "Most personal — written like a note from Priya to a friend"
    - platform: "Google (SEO/Search)"
      purpose: "Passive inbound lead generation"
      frequency: "2 blog posts/month"
      tone_modifier: "Helpful and clear — written for someone who just Googled their problem"
  topics_to_avoid:
    - "Overly technical accounting jargon in public-facing content"
    - "Anything that makes small business owners feel judged for their financial situation"
    - "Political content of any kind"
    - "Guaranteeing specific financial outcomes"
  hashtags: ["#ledgerandleaf#", "#smallbusinessfinance", "#bookkeepingtips", "#smallbusinessowner", "#remotebookkeeping"]
  keywords: ["small business bookkeeping", "remote bookkeeper", "bookkeeping for small business", "monthly bookkeeping service", "small business accounting"]

# --- CUSTOMER EXPERIENCE ---
experience:
  feeling_goal: "Like you finally have a financially competent adult in your corner who actually gives a damn about your business."
  service_standards:
    - "Respond to all client messages within 24 business hours — always"
    - "Monthly financials delivered by the 10th of each month, no exceptions"
    - "Never make a client feel stupid for not understanding something — explain it twice if needed"
    - "Proactively flag anything unusual — don't wait to be asked"
    - "Remember details about their business — we work with humans, not accounts"
  touchpoints:
    - name: "Clarity Call"
      description: "First conversation with a prospect"
      tone: "Warm, curious, zero pressure — we're figuring out if it's a fit together"
    - name: "Onboarding Welcome"
      description: "First email after signing"
      tone: "Reassuring and organized — 'here's exactly what happens next'"
    - name: "First Monthly Report"
      description: "Delivery of first set of financials"
      tone: "Explanatory and encouraging — walk them through what they're seeing"
    - name: "90-Day Check-In"
      description: "Scheduled call at 90 days"
      tone: "Collaborative — how is this working for you? What could be better?"
    - name: "Tax Season Prep Email"
      description: "Sent each January"
      tone: "Calm and proactive — 'here's what we're doing to make this easy'"
  onboarding_summary: "New clients complete a business profile form, grant read-only access to their accounts, and have a 30-minute kickoff call with their dedicated bookkeeper within the first week."
  retention_strategy: "Monthly touchpoints beyond just reports, annual business financial review, proactive catch of issues before they become problems, and referral program for happy clients."

# --- GOALS & KPIS ---
goals:
  current_priorities:
    - "Grow from 60 to 90 active clients"
    - "Hire one additional bookkeeper to support growth"
    - "Build LinkedIn presence to generate 5+ inbound leads per month"
    - "Formalize referral program with existing clients"
    - "Launch a 'starter' tier for new businesses under $100K revenue"
  kpis:
    - metric: "Active clients"
      target: "90"
      timeframe: "December 2026"
    - metric: "Monthly recurring revenue"
      target: "$45,000"
      timeframe: "December 2026"
    - metric: "Client churn rate"
      target: "Below 3% monthly"
      timeframe: "Ongoing"
    - metric: "Inbound leads from LinkedIn"
      target: "5+ per month"
      timeframe: "Q3 2026"
    - metric: "Referral rate"
      target: "40% of new clients from referrals"
      timeframe: "Ongoing"
  growth_stage: growth
  horizon: "12-month focus on sustainable growth without sacrificing service quality"

# --- CONSTRAINTS & NO-GOS ---
constraints:
  never_say:
    - "\"We're like your financial therapist\"" (undersells the expertise)
    - "\"Don't worry about it\"" (dismissive — always explain)
    - "\"It's complicated\"" (that's our job to uncomplicate)
    - "\"Per our last email\"" (cold, passive-aggressive — never)
  never_do:
    - "Take on more clients than we can serve well — quality over growth always"
    - "Make a client feel judged or embarrassed about their books"
    - "Go silent during tax season or high-stress periods — that's when communication matters most"
    - "Overpromise on timelines and underdeliver"
    - "Share client financial information — ever, with anyone, for any reason"
  never_look_like:
    - "A faceless corporate accounting firm — we are human and approachable"
    - "A tech startup — warm and personal, not cold and disruptive"
    - "An outdated, stodgy accounting practice — modern, clean, clear"
  legal_restrictions:
    - "Cannot provide tax advice — always refer to a licensed CPA or tax preparer for tax questions"
    - "Cannot guarantee specific financial outcomes"
    - "Client data governed by engagement letter and confidentiality agreement"
    - "Must maintain accurate CPA licensure disclosures in all marketing"
  sensitive_topics:
    - "Client financial situations — never reference even anonymously without explicit permission"
    - "IRS or audit mentions — handle with calm, not alarm"
    - "Pricing — be transparent, never defensive"
---

## Overview

Ledger & Leaf Bookkeeping is a remote bookkeeping firm built specifically for small business owners. Founded in 2020 by Priya Mathur, a licensed CPA and former Big Four accountant, Ledger & Leaf exists to solve a specific problem: small business owners need real, attentive financial support, and most accounting firms aren't built to give it to them.

We serve 60+ clients across 14 industries, all remotely, with a simple promise: your books will be clean, your questions will be answered, and you will never dread opening a financial email from us.

Our tagline — **Your numbers, handled.** — is a complete sentence and a complete promise.

---

## Brand Story

Priya Mathur spent eight years at a large Nashville accounting firm doing good work for clients who barely knew her name. The small business owners she met through friends kept asking her the same question: *do you know anyone good who actually works with people like us?*

The big firms didn't want them. The cheap services didn't serve them well. The DIY software left them more confused than before. There was a gap — not a technology gap, a relationship gap.

She left in 2020 with four clients and a home office. The timing was terrible (a global pandemic will do that) and also, it turned out, perfect — remote work normalized exactly the model she was building.

Ledger & Leaf now serves 60+ businesses with a team of three. Zero marketing budget. Zero client churn in 18 months. One hundred percent word of mouth.

The mission is the same as day one: take the financial stress off small business owners' plates so they can get back to doing work they love.

---

## Visual Identity

Ledger & Leaf's visual identity is clean, calm, and quietly confident. The palette is rooted in deep forest green — a color that signals trust, growth, and steadiness without feeling corporate or cold.

**Primary (#1B3A2D):** Deep forest green — grounding, trustworthy, calm authority.

**Secondary (#4A9B72):** Fresh mid-green — approachable, optimistic, alive.

**Accent (#A8D5B5):** Sage — soft, calming, used for backgrounds and highlights.

**Neutral (#F4F7F5):** Cool white with green undertone — clean without being sterile.

Typography pairs Fraunces (warm serif with a human feel — approachable expertise) with IBM Plex Sans (clear, technical, trustworthy). Together they say: we're serious about the work and easy to work with.

Photography is bright, real, and human — home offices, actual people working, hands on laptops. No stock photos of calculators or generic "business" imagery. The brand should look like the people who run it.

---

## Brand Personality

Ledger & Leaf sounds like a smart, calm friend who happens to be great with money. They don't talk down to you. They don't make you feel dumb for asking basic questions. And they genuinely want things to go well for you.

The brand is warm without being unprofessional. Knowledgeable without being intimidating. Calm — especially when the client isn't.

**Archetypes:** Caregiver (attentive, supportive, puts the client first) + Sage (expertise, clarity, cutting through confusion)

**In practice:**
- We translate numbers into plain English without being condescending
- We lead with reassurance, follow with information
- We take the work seriously and take the stress off the client
- We're the steady hand when tax season panic sets in

**Voice examples:**
- ✅ "Your February numbers are in. Revenue was up 12% — let me walk you through what's driving that."
- ✅ "This is more common than you think. Here's what it means and here's what we do about it."
- ❌ "Per our previous correspondence, please note the discrepancy in your Q2 reconciliation report."
- ❌ "As a CPA I must advise you that your current financial situation presents several areas of concern."

---

## Target Audience

Our primary client is someone we call **The Overwhelmed Owner** — a talented person who built something real, has no idea how to run the financial side of it, and feels a low-grade anxiety about money that never fully goes away.

They're not bad with money. They're just not accountants. And they started their business to do the thing they're good at — not to reconcile bank statements.

What they need from us:
- To feel like someone competent is handling it
- To understand their numbers without a crash course in accounting
- To trust that what we say is accurate and what we do is thorough
- To feel like a priority, not an afterthought

Our secondary client — **The New Business Owner** — is early stage and wants to build good habits from day one. Lower revenue now, high value long-term. We love serving them early.

---

## Market Positioning

Ledger & Leaf sits in the middle of the market — not a $99/month software tool, not a $3,000/month Big Four engagement. We're the human-first, relationship-driven option for small businesses that have outgrown DIY but don't need (and can't afford) an enterprise accounting firm.

Our differentiation isn't price or technology. It's the relationship. We know our clients' businesses. We remember what they told us last quarter. We check in, not just when the invoice is due.

That's rarer than it sounds.

---

## Competitive Landscape

The remote bookkeeping space has grown significantly. Most players go one of two directions: software-first (Bench, Pilot) or high-volume/low-touch (1-800Accountant). Both sacrifice the relationship for scale.

We don't scale that way. We grow by adding one client at a time and keeping them forever.

The brand we watch most is Bench — they've done good work on design and positioning. The difference: their bookkeepers are support staff. Ours are partners.

We don't want to be compared to H&R Block or TurboTax. Those are tax tools. We are a year-round financial partner.

---

## Messaging

Everything we say comes back to one thing: **your numbers, handled.**

That's the promise. Not "empowering you to understand your finances" (too much work for the client). Not "financial transformation" (too much hype). Just: it's handled. You can stop worrying about it.

We back that up with specifics — a real person, a real response time, real monthly deliverables, real CPA review. Every claim has something behind it.

---

## Sales Context

Bookkeeping is a trust purchase. No one hands over their financial accounts to someone they just found on Google without a conversation first. The Clarity Call is everything — it's where trust is built or lost.

Our job on that call is not to sell. It's to listen, understand the specific mess they're in, and show them — calmly, specifically — how we'd handle it.

The close happens when someone feels understood. Not impressed. Understood.

---

## Content Guidelines

Our content has one job: make a small business owner feel less alone with their finances.

We do that by being consistently useful, consistently human, and consistently calm. No doom-scrolling tax anxiety content. No jargon. No condescension.

LinkedIn is our most important channel — it's where our clients and referral sources are. Priya's personal voice drives more engagement than any brand account post ever will.

The content rule that overrides everything else: never make a small business owner feel judged for where their finances are right now.

---

## Customer Experience

Every interaction with Ledger & Leaf should feel the same way: calm, competent, and genuinely caring.

We are the financial version of a great doctor — someone who takes your concerns seriously, explains things clearly, and makes you feel like you're in good hands even when the news isn't perfect.

We measure experience by one number above all others: client retention. If the relationship is good and the work is good, clients stay. We've built a business on that assumption and it has held up.

---

## Goals & KPIs

2026 is a year of intentional growth. We want to add 30 clients — but only if we can maintain the service quality that's kept existing clients for 2+ years on average.

The referral program formalization is overdue. We get referrals constantly but informally. Making it intentional and rewarding it properly is the single highest-ROI move available to us.

---

## Constraints & No-Gos

We will never take on more clients than we can serve well. That's not a growth strategy — that's the business model.

We will never make a client feel judged. Whatever state their books are in when they come to us, we've seen worse and we'll fix it without comment.

And we will never, under any circumstances, share client financial information. That's not a policy. That's who we are.
