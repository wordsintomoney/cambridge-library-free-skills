---
version: "1.0"
name: Groundwork Coffee Co.
description: Small-batch specialty coffee for people who take their mornings seriously.
created: 2026-04-01
updated: 2026-04-26

# --- VISUAL IDENTITY ---
colors:
  primary: "#1C1008"
  secondary: "#C67D3A"
  accent: "#E8B87D"
  neutral: "#F5F0E8"
  background: "#FDFAF5"
  surface: "#EDE8DE"
  on-primary: "#FDFAF5"
  on-secondary: "#1C1008"
  error: "#B03A2E"
  success: "#2E7D32"

typography:
  display:
    fontFamily: "Playfair Display"
    fontSize: "48px"
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: "-0.5px"
  heading:
    fontFamily: "Playfair Display"
    fontSize: "28px"
    fontWeight: 600
  body:
    fontFamily: "Inter"
    fontSize: "16px"
    fontWeight: 400
    lineHeight: 1.7
  label:
    fontFamily: "Inter"
    fontSize: "13px"
    fontWeight: 600
  caption:
    fontFamily: "Inter"
    fontSize: "12px"

spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "32px"
  xl: "64px"

rounded:
  sm: "4px"
  md: "8px"
  lg: "16px"
  full: "9999px"

logo:
  primary_url: "https://groundworkcoffee.co/assets/logo-primary.svg"
  dark_url: "https://groundworkcoffee.co/assets/logo-dark.svg"
  light_url: "https://groundworkcoffee.co/assets/logo-light.svg"
  icon_url: "https://groundworkcoffee.co/assets/icon.svg"
  minimum_size: "120px"
  clear_space: "16px"

# --- BRAND PERSONALITY ---
personality:
  archetypes: ["Sage", "Creator"]
  adjectives: ["warm", "grounded", "honest", "craft-forward", "unpretentious"]
  tone: "warm and knowledgeable, never snobby"
  voice_style: "conversational with depth — like a friend who really knows coffee"
  formality: low

# --- BRAND STORY ---
story:
  founded: 2019
  mission: "Make exceptional coffee accessible to people who care about what's in their cup — without the gatekeeping."
  vision: "A world where great coffee is part of everyday life, not a special occasion."
  values: ["craft", "transparency", "accessibility", "community", "sustainability"]
  tagline: "Start from good ground."
  origin_summary: "Groundwork started in a garage in Austin, TX when founder Maya Reyes got frustrated that the best coffee always seemed to come with a side of attitude. She wanted specialty-grade beans with zero pretension. What started as weekend roasting for friends became a subscription brand serving 12,000+ households across the US."

# --- TARGET AUDIENCE ---
audience:
  primary:
    name: "The Intentional Morning Person"
    age_range: "28–45"
    gender: "all"
    income: "$65,000–$120,000"
    education: "College-educated"
    location: "Mid-size US cities and suburbs"
    psychographics:
      - "Values quality over quantity"
      - "Has rituals — coffee is one of them"
      - "Curious and self-educated"
      - "Skeptical of marketing fluff"
      - "Cares where things come from"
    pain_points:
      - "Good coffee at local cafes is expensive and inconvenient daily"
      - "Grocery store coffee feels like a downgrade"
      - "Specialty coffee culture feels intimidating and elitist"
      - "Hard to know if a brand actually does what it claims"
    goals:
      - "A reliable, excellent cup every morning"
      - "To feel good about what they're buying"
      - "Simple subscriptions that don't require a PhD in coffee"
  secondary:
    name: "The Home Barista"
    description: "Coffee enthusiasts who experiment with brew methods, grind settings, and origin profiles. They want more technical detail and love exploring single-origins."
  not_for:
    - "People who just want the cheapest option"
    - "Cafes or wholesale buyers (B2C only)"
    - "People who don't actually drink coffee (gift buyers only — low LTV)"

# --- MARKET POSITIONING ---
positioning:
  category: "Specialty Coffee"
  subcategory: "Direct-to-consumer coffee subscription"
  tier: premium
  differentiation: "We make specialty coffee feel like it was always meant for you — no jargon, no judgment, just genuinely great beans with the story behind them."
  perception_goal: "The brand that made me feel like I actually belonged in specialty coffee."
  against:
    - "Coffee snobbery and gatekeeping culture"
    - "Commodity coffee that prioritizes price over quality"
    - "Subscription services that auto-ship and hope you forget"

# --- COMPETITIVE LANDSCAPE ---
competitors:
  - name: "Trade Coffee"
    url: "https://www.drinktrade.com"
    relationship: direct
    how_different: "Trade is a marketplace; we are a single-source brand with a consistent roasting philosophy and a stronger community voice."
    do_not_become: false
  - name: "Starbucks at Home"
    url: "https://www.starbucks.com"
    relationship: indirect
    how_different: "Mass-market brand recognition vs. our craft credibility and transparency. Different buyer entirely."
    do_not_become: true
  - name: "Blue Bottle Coffee"
    url: "https://bluebottlecoffee.com"
    relationship: aspirational
    how_different: "Blue Bottle is premium but has gone corporate. We stay independent, approachable, and community-first."
    do_not_become: false

avoid_comparison_to: ["Starbucks", "Nespresso", "Keurig"]

# --- MESSAGING ---
messaging:
  elevator_pitch: "Groundwork Coffee Co. is a small-batch specialty coffee subscription for people who want exceptional coffee without the attitude. We source transparently, roast carefully, and ship directly to your door."
  headline: "Great coffee. No gatekeeping."
  subheadline: "Small-batch specialty coffee, roasted fresh and shipped to your door. No jargon. No judgment. Just a really good cup."
  value_propositions:
    - "Specialty-grade beans roasted fresh, not sitting in a warehouse"
    - "Full origin transparency — you know exactly where your coffee came from"
    - "No intimidating menus or confusing tiers — easy to get started"
    - "Flexible subscription with no tricks to cancel"
    - "A brand that actually talks to you like a person"
  proof_points:
    - "12,000+ active subscribers across the US"
    - "4.9 stars across 3,200+ reviews"
    - "Featured in Bon Appétit, Food52, and The Strategist"
    - "Direct relationships with 14 farms across 6 countries"
    - "Carbon-neutral shipping since 2022"
  calls_to_action:
    primary: "Start Your Subscription"
    secondary: "Try a Starter Box"
  messaging_hierarchy:
    - level: 1
      message: "Exceptional coffee shouldn't come with a side of attitude."
    - level: 2
      message: "We source directly from farms we trust, roast in small batches, and ship to your door — fresh."
    - level: 3
      message: "Flexible subscriptions, full transparency, and a community that actually talks coffee without the gatekeeping."

# --- SALES CONTEXT ---
sales:
  avg_deal_size: "$18–$28/month subscription"
  sales_cycle: "Same session — low-consideration purchase"
  primary_channel: "Organic social + word of mouth + email"
  deal_breakers:
    - "Perceived high price without understanding the value"
    - "Commitment anxiety around subscriptions"
    - "Confusion about which roast/origin to pick"
  objections:
    - objection: "It's too expensive."
      response: "Per cup, Groundwork costs less than $1.50 — cheaper than a café and better than the grocery store. And you know exactly where every bean came from."
    - objection: "I'm worried about being locked in."
      response: "There's no lock-in. Pause, skip, or cancel anytime in two clicks. No emails to send, no phone calls. We built it that way on purpose."
    - objection: "I don't know enough about coffee to choose."
      response: "You don't need to. Answer three questions about how you drink coffee and we'll match you. That's it."
  closers:
    - "Starter box offer with low commitment"
    - "Social proof from relatable, non-coffee-snob reviewers"
    - "Free shipping threshold met early"
  red_flags:
    - "Asking for wholesale pricing (not our model)"
    - "Only interested in the cheapest option"
    - "Looking for flavored coffees or pods"

# --- CONTENT GUIDELINES ---
content:
  pillars:
    - "The craft behind the cup (sourcing, roasting, brewing)"
    - "Morning rituals and routines"
    - "Farm and origin stories"
    - "Coffee education without the intimidation"
    - "Community and customer stories"
  formats:
    - "Short-form video (Reels, TikTok)"
    - "Email newsletter (weekly)"
    - "Long-form blog (SEO)"
    - "User-generated content reposts"
    - "Behind-the-scenes photo content"
  channels:
    - platform: "Instagram"
      purpose: "Brand aesthetic, community building, UGC"
      frequency: "5x per week"
      tone_modifier: "Warmer, more personal, more visual storytelling"
    - platform: "TikTok"
      purpose: "Education, reach, behind-the-scenes"
      frequency: "3x per week"
      tone_modifier: "More casual, lo-fi, real — less polished"
    - platform: "Email"
      purpose: "Retention, education, product discovery"
      frequency: "Weekly"
      tone_modifier: "Most personal — written like a letter from a friend"
    - platform: "Pinterest"
      purpose: "SEO, lifestyle inspiration, recipe content"
      frequency: "3x per week"
      tone_modifier: "Aspirational but achievable"
  topics_to_avoid:
    - "Political opinions of any kind"
    - "Other brands' products (no comparisons in content)"
    - "Overclaiming health benefits"
    - "Anything that makes coffee feel exclusive or hard"
  hashtags: ["#groundworkcoffee", "#startfromgoodground", "#specialtycoffee", "#morningritual", "#coffeeroaster"]
  keywords: ["small batch coffee", "specialty coffee subscription", "fresh roasted coffee", "direct trade coffee", "best coffee subscription"]

# --- CUSTOMER EXPERIENCE ---
experience:
  feeling_goal: "Like you found your people — a brand that gets you, doesn't talk down to you, and genuinely cares whether the coffee is good."
  service_standards:
    - "Respond to all support messages within 4 business hours"
    - "Always offer a solution, not just an explanation"
    - "Use first names. Always."
    - "Never make a customer fight to cancel — make it easy and thank them"
    - "Turn complaints into stories — most unhappy customers become loyal ones"
  touchpoints:
    - name: "Welcome Email"
      description: "First email after subscription signup"
      tone: "Warm, like a personal welcome from Maya — not a corporate drip sequence"
    - name: "Shipping Confirmation"
      description: "When the box ships"
      tone: "Excited, like you're both looking forward to this"
    - name: "Unboxing Insert"
      description: "Card inside the box"
      tone: "Personal, handwritten feel — origin story of the current roast"
    - name: "Review Request"
      description: "7 days after delivery"
      tone: "Low pressure, genuine — 'We'd love to know what you think'"
    - name: "Cancellation Flow"
      description: "When a subscriber cancels"
      tone: "Gracious, no guilt — leave the door open warmly"
  onboarding_summary: "New subscribers complete a 3-question coffee preference quiz, receive a personalized roast match, and get a welcome email from Maya within minutes of signup."
  retention_strategy: "Monthly origin spotlights, loyalty rewards at 3/6/12 months, skip-don't-cancel nudges, and a private community Slack for subscribers."

# --- GOALS & KPIS ---
goals:
  current_priorities:
    - "Grow active subscriber base from 12K to 20K by end of year"
    - "Increase average subscription duration from 4.2 months to 7 months"
    - "Launch wholesale-adjacent café partner program (pilot)"
    - "Build owned community (Slack/Circle) to reduce churn"
  kpis:
    - metric: "Active subscribers"
      target: "20,000"
      timeframe: "December 2026"
    - metric: "Average subscription lifespan"
      target: "7 months"
      timeframe: "December 2026"
    - metric: "Monthly churn rate"
      target: "Below 5%"
      timeframe: "Ongoing"
    - metric: "Email open rate"
      target: "42%"
      timeframe: "Ongoing"
    - metric: "Net Promoter Score"
      target: "72+"
      timeframe: "Q3 2026"
  growth_stage: growth
  horizon: "12-month focus on retention and community depth over pure acquisition"

# --- CONSTRAINTS & NO-GOS ---
constraints:
  never_say:
    - "Third wave" (too insider)
    - "Curated" (overused, meaningless)
    - "Artisanal" (played out)
    - "Elevate your morning" (too generic)
    - "Premium" without specifics (claim it, don't say it)
  never_do:
    - "Run fake urgency campaigns (\"Only 3 left!\" when that's not true)"
    - "Make cancellation deliberately difficult"
    - "Post content that makes non-experts feel dumb"
    - "Partner with brands that conflict with sustainability values"
    - "Use stock photography of coffee — always real product, real people"
  never_look_like:
    - "Fast food or mass-market coffee chains (too corporate)"
    - "Over-designed, cold, minimalist brands that feel unapproachable"
    - "Overly rustic or \"farmhouse\" aesthetic — warm but modern"
  legal_restrictions:
    - "No health claims beyond general wellness associations"
    - "FTC compliance required on all influencer partnerships"
    - "Fair trade and direct trade claims must be verifiable"
  sensitive_topics:
    - "Caffeine and health (stick to enjoyment framing, not medical)"
    - "Farm labor conditions (handle with care and full accuracy)"
    - "Pricing (don't apologize for it, don't overclaim value either)"
---

## Overview

Groundwork Coffee Co. is a small-batch specialty coffee subscription brand based in Austin, TX. Founded in 2019 by Maya Reyes, Groundwork exists to close the gap between exceptional coffee and the everyday person — without the gatekeeping that's plagued the specialty coffee world for decades.

We source directly from farms we know and trust, roast in small batches, and ship fresh to subscribers across the US. Everything we do is built on two things: the quality of the coffee and the quality of how we make people feel when they interact with us.

Our tagline — **Start from good ground** — is both literal and philosophical. It's about the beans. It's also about the idea that great things begin when you get the foundation right.

---

## Brand Story

Maya Reyes spent three years working at specialty coffee shops in Austin and grew increasingly frustrated by something she couldn't shake: the culture was excluding the exact people it should have been serving. Great coffee was being gatekept behind jargon, intimidating menus, and a subtle but real message that said *this isn't for you*.

She started roasting at home in 2018, sharing bags with neighbors and coworkers. The feedback was immediate. People didn't just love the coffee — they loved that someone finally made them feel like they belonged in the conversation.

Groundwork launched direct-to-consumer in 2019 with a single subscription tier and a waiting list. Within 18 months it had grown entirely by word of mouth to 4,000 subscribers. By 2023, it crossed 10,000.

The mission has never changed: make exceptional coffee feel like it was always meant for you.

---

## Visual Identity

Groundwork's visual identity is warm, honest, and grounded (literally). The color palette draws from the roasting process — deep espresso browns, golden caramel tones, and clean cream neutrals. Nothing feels cold or corporate.

**Primary color (#1C1008):** Deep roast brown — anchors the brand in craft and seriousness without heaviness.

**Secondary color (#C67D3A):** Medium roast caramel — warm, inviting, the color of a well-pulled shot.

**Accent (#E8B87D):** Light roast gold — used sparingly for highlights and warmth.

**Neutral (#F5F0E8):** Off-white with warmth — never stark white, always feels like paper or linen.

Typography pairs Playfair Display (editorial warmth, craft credibility) with Inter (clarity, readability at any size). The combination says: we take this seriously, and we're easy to be around.

Photography is always real — real beans, real people, real mornings. Never stock. The aesthetic is warm and natural light, slightly imperfect, honest.

---

## Brand Personality

Groundwork sounds like that friend who really knows coffee but never makes you feel bad for not knowing as much. They're enthusiastic without being overwhelming. Honest about what they care about. Warm but not gushing.

The brand never lectures. It invites.

**Archetypes:** Sage (knowledge, guidance, demystification) + Creator (craft, care, making something real)

**In practice:**
- We explain, we don't preach
- We have opinions, but we hold them lightly
- We celebrate the ritual without gatekeeping it
- We're serious about quality, casual about everything else

**Voice examples:**
- ✅ "This one's a little fruity, a little chocolatey. It's the kind of cup that makes you slow down."
- ✅ "We picked this farm because the relationship is real — not because it looks good on a label."
- ❌ "Experience the nuanced tertiary notes of this single-origin Ethiopian natural process."
- ❌ "Elevate your morning ritual with our curated artisanal selection."

---

## Target Audience

Our primary customer is someone we call **The Intentional Morning Person.** They've graduated from grocery store coffee but haven't — and don't want to — become a coffee obsessive. They want something excellent, simple, and honest.

They read labels. They care where things come from. They're skeptical of brands that over-promise. And they've probably been made to feel dumb in a coffee shop at least once.

**What they need from us:**
- Confidence that the coffee is actually good
- Easy entry — no quiz with 40 questions, no overwhelming options
- A brand that feels like *their* kind of people
- Proof that we do what we say

Our secondary audience — **The Home Barista** — wants more. More origin detail, more roast notes, more technical content. We serve them through our blog, email deep-dives, and single-origin spotlights without making that the default experience for everyone.

---

## Market Positioning

Groundwork sits at the intersection of specialty quality and mainstream accessibility — a position very few brands hold credibly.

We are not a commodity coffee brand. We are not a gatekeeping specialty roaster. We are the bridge.

Our differentiation is not just the coffee — it's the culture we've built around it. The transparency. The tone. The way we talk to people.

We position against **the attitude**, not just the competition.

---

## Competitive Landscape

The specialty DTC coffee space is crowded, but most players fall into one of two camps: cold and design-forward (Blue Bottle pre-acquisition, La Colombe) or marketplace-aggregated (Trade Coffee, Atlas). Groundwork is neither.

We are a roaster with a voice. That combination — craft credibility + genuine brand personality — is rare.

**What we are not:** We are not Starbucks. We are not trying to be. That comparison is the fastest way to misunderstand us.

---

## Messaging

Everything we say starts with one truth: **great coffee shouldn't come with a side of attitude.**

Our headline — *Great coffee. No gatekeeping.* — is both a product promise and a cultural statement. It's what we stand for.

Our value propositions are concrete:
- The beans are genuinely specialty-grade, roasted fresh (not warehoused)
- You know exactly where your coffee came from
- Getting started is simple — no overwhelm
- The subscription is flexible and honest
- We actually talk to you like a person

We prove our claims. Every value prop has a proof point behind it.

---

## Sales Context

Groundwork is a low-consideration, high-emotion purchase. People don't agonize over it — but they do need to feel something before they buy.

The biggest barrier is not price or competition. It's **subscription anxiety** and **choice paralysis**. Our job in the sales journey is to reduce both:

1. Make the first step feel small (Starter Box, quiz-based match)
2. Make the commitment feel safe (easy cancel, no tricks)
3. Make the quality feel obvious (reviews, specificity, proof)

The conversion happens when someone feels like this brand *gets them.*

---

## Content Guidelines

Our content has one job: make people feel like Groundwork is their kind of brand before they've ever bought a bag.

We own five content pillars: craft and process, morning rituals, origin stories, accessible education, and community. Everything we publish lives in one of those five spaces.

We post on Instagram and TikTok as our primary discovery channels, email as our primary retention channel. Pinterest for SEO reach. Each channel gets a tone modifier — email is the most personal, TikTok the most raw.

We never publish content that makes someone feel like they're not a "real" coffee person. That's the one rule that overrides everything else.

---

## Customer Experience

Every interaction with Groundwork should feel the same way: like you found your people.

Warm, knowledgeable, never condescending. Fast when it counts. Personal always.

The experience starts before the first bag arrives — with the welcome email, the quiz, the confirmation. It continues through the unboxing insert, the review request, and eventually the cancellation flow (which should be so gracious that people feel good about coming back).

We measure experience not just by CSAT but by how many people come back after canceling. That number tells us whether we actually delivered on the promise.

---

## Goals & KPIs

2026 is a retention year. We have the acquisition engine working. Now we build depth.

Primary focus: extend subscriber lifetime value, reduce churn, build community infrastructure that makes Groundwork feel like more than a product.

Secondary focus: explore a café partner pilot that extends brand presence without compromising the DTC model.

---

## Constraints & No-Gos

The things we will never do are as important as the things we will.

We will never make cancellation hard. We will never use fake urgency. We will never post stock photography. We will never make someone feel dumb for not knowing coffee.

And we will never — under any circumstances — get compared to Starbucks without correcting the record.
