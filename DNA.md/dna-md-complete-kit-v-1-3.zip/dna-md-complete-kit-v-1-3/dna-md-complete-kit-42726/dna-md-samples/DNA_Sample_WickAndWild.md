---
version: "1.0"
name: Wick & Wild Co.
description: Small-batch soy candles made for people who turn their home into a vibe.
created: 2026-04-27
updated: 2026-04-27

# --- VISUAL IDENTITY ---
colors:
  primary: "#2C2C2C"
  secondary: "#D4A96A"
  accent: "#E8D5B7"
  neutral: "#F9F6F1"
  background: "#FFFFFF"
  surface: "#F2EDE4"
  on-primary: "#FFFFFF"
  on-secondary: "#2C2C2C"
  error: "#B03A2E"
  success: "#4A7C59"

typography:
  display:
    fontFamily: "Cormorant Garamond"
    fontSize: "52px"
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: "-0.5px"
  heading:
    fontFamily: "Cormorant Garamond"
    fontSize: "30px"
    fontWeight: 600
  body:
    fontFamily: "DM Sans"
    fontSize: "16px"
    fontWeight: 400
    lineHeight: 1.75
  label:
    fontFamily: "DM Sans"
    fontSize: "12px"
    fontWeight: 600
  caption:
    fontFamily: "DM Sans"
    fontSize: "11px"

spacing:
  xs: "4px"
  sm: "8px"
  md: "16px"
  lg: "32px"
  xl: "64px"

rounded:
  sm: "2px"
  md: "6px"
  lg: "12px"
  full: "9999px"

logo:
  primary_url: "https://wickandwild.co/assets/logo-primary.svg"
  dark_url: "https://wickandwild.co/assets/logo-dark.svg"
  light_url: "https://wickandwild.co/assets/logo-light.svg"
  icon_url: "https://wickandwild.co/assets/icon.svg"
  minimum_size: "100px"
  clear_space: "16px"

# --- BRAND PERSONALITY ---
personality:
  archetypes: ["Creator", "Lover"]
  adjectives: ["sensory", "intimate", "earthy", "playful", "intentional"]
  tone: "warm and a little witty — like a friend who always has great taste"
  voice_style: "casual, sensory-rich, with a dry sense of humor"
  formality: low

# --- BRAND STORY ---
story:
  founded: 2022
  mission: "Make your home smell like the best version of itself — with candles poured with actual care."
  vision: "A home goods brand synonymous with mood, ritual, and the small luxuries that make everyday life feel good."
  values: ["craftsmanship", "sustainability", "sensory experience", "slow living", "self-expression"]
  tagline: "Set the mood."
  origin_summary: "Wick & Wild started on a kitchen counter in Portland, OR when founder Jade Okonkwo couldn't find a candle that smelled the way she wanted her apartment to feel — warm, a little wild, completely her. She started pouring her own soy wax candles in 2022, posted a batch on Instagram, sold out in 48 hours, and never looked back. Three years later Wick & Wild ships nationwide and has a cult following of home-obsessed millennials and Gen Z buyers."

# --- TARGET AUDIENCE ---
audience:
  primary:
    name: "The Aesthetic Homebody"
    age_range: "22–38"
    gender: "predominantly women, all genders welcome"
    income: "$40,000–$90,000"
    education: "Some college to college-educated"
    location: "Urban and suburban US — heavy on the coasts and mid-size creative cities"
    psychographics:
      - "Heavily influenced by TikTok and Instagram aesthetics"
      - "Treats their home as a form of self-expression"
      - "Buys intentionally — prefers small brands over big box"
      - "Values the ritual as much as the product"
      - "Loves gifting and being gifted"
    pain_points:
      - "Mass-market candles smell fake or burn out fast"
      - "\"Clean\" candles are often boring or overpriced"
      - "Hard to find candles with genuinely unique, interesting scents"
      - "Most candle brands feel generic — no personality"
    goals:
      - "A home that feels curated and intentional"
      - "Products that double as decor"
      - "Something that feels special to gift"
  secondary:
    name: "The Gifter"
    description: "Buying for someone else — birthdays, housewarmings, holidays. Needs something that looks and feels premium but isn't intimidating. They want the packaging to do the talking."
  not_for:
    - "Bargain hunters — we're not the cheapest option and don't pretend to be"
    - "Buyers who don't care about ingredients or sourcing"
    - "Corporate bulk gift buyers (minimum order quantities too high for our model)"

# --- MARKET POSITIONING ---
positioning:
  category: "Home Fragrance"
  subcategory: "Small-batch handmade soy candles, DTC"
  tier: premium
  differentiation: "We make candles with scent profiles that actually feel like a place, a mood, or a memory — not just 'vanilla' or 'ocean breeze.' And we do it in small batches with 100% soy wax, clean fragrance, and packaging you'd genuinely want on your shelf."
  perception_goal: "The candle brand my whole aesthetic is built around."
  against:
    - "Generic mass-market candles that smell synthetic"
    - "Wellness brands that take themselves too seriously"
    - "Overpriced minimalist brands with no personality"

# --- COMPETITIVE LANDSCAPE ---
competitors:
  - name: "Homesick Candles"
    url: "https://homesick.com"
    relationship: direct
    how_different: "Homesick leans into nostalgia and place; we lean into mood and vibe. Our scent profiles are more abstract and personality-driven."
    do_not_become: false
  - name: "Yankee Candle"
    url: "https://www.yankeecandle.com"
    relationship: indirect
    how_different: "Mass market, synthetic fragrance, no brand personality. The opposite of us."
    do_not_become: true
  - name: "Boy Smells"
    url: "https://boysmells.com"
    relationship: aspirational
    how_different: "Boy Smells nailed brand voice and premium positioning. We're more accessible, more playful, and more community-driven."
    do_not_become: false

avoid_comparison_to: ["Yankee Candle", "Bath & Body Works", "Febreze"]

# --- MESSAGING ---
messaging:
  elevator_pitch: "Wick & Wild Co. makes small-batch soy candles with scent profiles built around moods, not just notes — for people who take their home seriously and their aesthetics personally."
  headline: "Set the mood."
  subheadline: "Small-batch soy candles poured for people who know exactly how their home should feel."
  value_propositions:
    - "100% soy wax — clean burn, longer lasting, better for your air"
    - "Scent profiles built around moods and moments, not generic categories"
    - "Small-batch poured — every candle made by hand in Portland, OR"
    - "Packaging designed to live on your shelf, not get thrown away"
    - "Straightforward ingredients — no greenwashing, no vague 'clean' claims"
  proof_points:
    - "40,000+ candles sold since 2022"
    - "4.8 stars across 6,500+ reviews on Shopify and Etsy"
    - "Sold out 4 limited-edition drops in under 24 hours"
    - "Featured in Apartment Therapy, Refinery29, and Who What Wear"
    - "35% of customers are repeat buyers"
  calls_to_action:
    primary: "Shop the Collection"
    secondary: "Find Your Scent"
  messaging_hierarchy:
    - level: 1
      message: "Your home should smell like you want to feel."
    - level: 2
      message: "We pour small batches of soy wax candles designed around moods, not just notes."
    - level: 3
      message: "Clean ingredients, intentional packaging, and scent profiles you won't find anywhere else."

# --- SALES CONTEXT ---
sales:
  avg_deal_size: "$28–$58 per order (single candle to gift set)"
  sales_cycle: "Impulse to same-session — high emotion, low consideration"
  primary_channel: "TikTok and Instagram organic + Etsy + email"
  deal_breakers:
    - "Price without context (looks expensive before value is communicated)"
    - "Uncertainty about scent — can't smell it before buying"
    - "Shipping cost killing the deal at checkout"
  objections:
    - objection: "I can't smell it before I buy."
      response: "Every product page has a 'what it smells like in words' description — written like you're actually in the room. Plus, we offer a scent quiz and a sampler set for first-timers."
    - objection: "It's expensive for a candle."
      response: "It burns for 55+ hours on soy wax — most mass candles give you 20-30. Per hour of burn time, we're cheaper than Yankee Candle and you're not putting synthetic fragrance in your air."
    - objection: "What if I don't like the scent?"
      response: "We have a 'Not Your Vibe' policy — if your first candle isn't right, we'll swap it. No hoops."
  closers:
    - "Scent quiz that creates a personalized recommendation"
    - "Limited-edition drops that create urgency without fake tactics"
    - "Gift sets with beautiful packaging — easy gifting decision"
    - "Sampler pack as a low-commitment entry point"
  red_flags:
    - "Asking for wholesale pricing on single units"
    - "Wanting artificial fragrance or paraffin wax specifically"
    - "Buyers who only care about price"

# --- CONTENT GUIDELINES ---
content:
  pillars:
    - "The ritual (how candles fit into everyday moments)"
    - "Behind the pour (process, ingredients, small-batch craft)"
    - "Scent storytelling (what each scent feels like in words)"
    - "Home aesthetics and styling"
    - "Community and customer moments"
  formats:
    - "Short-form video (TikTok, Reels)"
    - "Aesthetic product photography"
    - "Email newsletter (biweekly)"
    - "UGC reposts"
    - "Long-form scent descriptions (website)"
  channels:
    - platform: "TikTok"
      purpose: "Discovery, brand personality, behind-the-scenes"
      frequency: "4–5x per week"
      tone_modifier: "Most raw and personality-forward — Jade's voice, not a brand voice"
    - platform: "Instagram"
      purpose: "Aesthetic brand world, product drops, UGC"
      frequency: "4x per week"
      tone_modifier: "More polished than TikTok but still warm and personal"
    - platform: "Email"
      purpose: "Retention, drop announcements, scent storytelling"
      frequency: "Biweekly"
      tone_modifier: "Most intimate — reads like a note from Jade, not a newsletter"
    - platform: "Etsy"
      purpose: "Discovery for new buyers, review building"
      frequency: "Ongoing listings"
      tone_modifier: "Warm, detailed, SEO-conscious but not robotic"
    - platform: "Pinterest"
      purpose: "Passive SEO, home inspo, gifting content"
      frequency: "2x per week"
      tone_modifier: "Purely aspirational — let the aesthetic do the talking"
  topics_to_avoid:
    - "Health claims about soy wax beyond clean burn"
    - "Anything that sounds like a wellness lecture"
    - "Competitor callouts (let the product speak)"
    - "Overused candle clichés: 'self-care,' 'treat yourself,' 'cozy season'"
  hashtags: ["#wickandwild", "#setthemood", "#soywaxcandles", "#smallbatchcandles", "#homeaesthetic", "#candletok"]
  keywords: ["soy wax candles", "small batch candles", "handmade candles Portland", "aesthetic candles", "best soy candles", "mood candles"]

# --- CUSTOMER EXPERIENCE ---
experience:
  feeling_goal: "Like you just discovered your new favorite brand — and you can't wait to tell someone about it."
  service_standards:
    - "Respond to all DMs and emails within 24 hours"
    - "Every order includes a handwritten-style thank you insert"
    - "Make returns and swaps painless — no guilt, no friction"
    - "Treat every customer like they're part of the community, not a transaction"
    - "Packaging should feel like opening a gift, even if it's for yourself"
  touchpoints:
    - name: "Order Confirmation Email"
      description: "Immediately after purchase"
      tone: "Excited and warm — like Jade personally packed the order"
    - name: "Shipping Notification"
      description: "When order ships"
      tone: "Playful — 'Your vibe is on its way'"
    - name: "Unboxing Insert"
      description: "Card inside the box"
      tone: "Personal, sensory — describes the scent and the mood it was made for"
    - name: "Post-Purchase Email (Day 7)"
      description: "Check-in after delivery"
      tone: "Casual — 'How's the vibe?' — not a formal review request"
    - name: "Loyalty Milestone"
      description: "At 3rd and 5th purchase"
      tone: "Celebratory, community-feeling — welcome to the inner circle"
  onboarding_summary: "New customers land on a scent quiz that recommends their first candle. Post-purchase they receive a welcome sequence with scent care tips, behind-the-scenes content, and an intro to the community."
  retention_strategy: "Limited-edition seasonal drops, a loyalty program with early access perks, biweekly email with scent stories, and a private community Instagram group for superfans."

# --- GOALS & KPIS ---
goals:
  current_priorities:
    - "Scale from $280K to $500K annual revenue"
    - "Grow email list from 8,500 to 20,000 subscribers"
    - "Launch first wholesale partnership (boutique retail, 5 doors)"
    - "Build TikTok to 100K followers"
    - "Introduce a subscription candle club"
  kpis:
    - metric: "Annual revenue"
      target: "$500,000"
      timeframe: "December 2026"
    - metric: "Email list size"
      target: "20,000"
      timeframe: "December 2026"
    - metric: "TikTok followers"
      target: "100,000"
      timeframe: "September 2026"
    - metric: "Repeat purchase rate"
      target: "42%"
      timeframe: "Ongoing"
    - metric: "Average order value"
      target: "$48"
      timeframe: "Ongoing"
  growth_stage: growth
  horizon: "12-month focus on revenue growth, community depth, and first retail presence"

# --- CONSTRAINTS & NO-GOS ---
constraints:
  never_say:
    - "Self-care" (overused, eye-roll territory)
    - "Cozy season" (seasonal cliché)
    - "Treat yourself" (played out)
    - "Artisanal" (nobody believes it anymore)
    - "Luxury" without context (claim it through specifics, not the word)
  never_do:
    - "Use paraffin wax or synthetic dyes — ever"
    - "Greenwash — every sustainability claim must be accurate and specific"
    - "Run fake scarcity tactics ('Only 2 left!' when that's not true)"
    - "Post overly polished, soulless content — the lo-fi realness is the brand"
    - "Collaborate with brands that conflict with clean/sustainable values"
  never_look_like:
    - "Big box candle brands — no generic product-on-white-background energy"
    - "Over-clinical wellness brands — we're warm, not sterile"
    - "Fast fashion aesthetic — we're intentional, slow, considered"
  legal_restrictions:
    - "No medical or therapeutic claims about fragrance or soy wax"
    - "FTC compliance on all influencer and gifted partnerships"
    - "Fragrance ingredient transparency per California Cleaning Product Right to Know Act"
  sensitive_topics:
    - "Fire safety — always include care instructions, never minimize"
    - "Fragrance sensitivities — be honest about scent strength"
    - "Pricing — don't apologize for it, do justify it through specifics"
---

## Overview

Wick & Wild Co. is a small-batch soy candle brand born in Portland, OR in 2022. Founded by Jade Okonkwo after a frustrating search for candles that actually felt personal, Wick & Wild exists to fill your home with scents that feel like moods — not marketing categories.

Every candle is hand-poured in small batches using 100% soy wax and clean fragrance. The packaging is designed to live on your shelf. The scent profiles are built around how you want to feel — not just what season it is.

Our tagline — **Set the mood.** — says everything. Two words. No explanation needed.

---

## Brand Story

Jade Okonkwo had a beautiful apartment and a candle problem. Everything she could find either smelled like a department store elevator or cost more than her electricity bill. She wanted something earthy, warm, a little unexpected — something that smelled like *her* apartment, not everyone else's.

She started pouring in 2022. Posted a batch on Instagram mostly as a joke. Sold out in 48 hours. Took that as a sign.

Wick & Wild has grown entirely through community and content — no paid ads, no PR agency, no outside investment. Just Jade, a growing team, and a lot of soy wax. The brand crossed $280K in revenue in year three entirely on word of mouth and organic social.

The mission has never changed: make your home smell like the best version of itself.

---

## Visual Identity

Wick & Wild's visual world is warm, editorial, and a little moody. Think candlelight on dark surfaces. Amber tones. Imperfect textures. The kind of image that makes you want to be in that room.

**Primary (#2C2C2C):** Near-black — sophisticated, grounding, lets the warm tones breathe.

**Secondary (#D4A96A):** Warm amber gold — the color of a lit candle, the center of the brand.

**Accent (#E8D5B7):** Soft sand — used for backgrounds and warmth in photography.

**Neutral (#F9F6F1):** Warm white — never cold, always inviting.

Typography pairs Cormorant Garamond (editorial elegance, slightly romantic) with DM Sans (clean, modern, easy to read). The combination says: we have taste and we're not pretentious about it.

Photography is always warm, textured, and a little imperfect. Natural light, real surfaces, real moments. Never white-background product shots. The candle should look like it belongs in someone's home — because it does.

---

## Brand Personality

Wick & Wild sounds like your most aesthetically dialed-in friend — the one whose apartment always looks incredible and who somehow knows about every good brand before it blows up. She has opinions. She's not trying to impress you. She just genuinely loves this stuff.

The brand is warm without being saccharine. Witty without trying too hard. It takes the craft seriously and the marketing lightly.

**Archetypes:** Creator (craft, beauty, making things with intention) + Lover (sensory experience, intimacy, emotional connection)

**In practice:**
- We describe scents like we're setting a scene, not listing ingredients
- We talk about candles as mood-setters, not wellness products
- We're playful but we don't chase trends — we set them
- We celebrate the ordinary moment: the Sunday morning, the bath at 9pm, the dinner party with two people

**Voice examples:**
- ✅ "This one smells like the Sunday morning you actually had time for. Warm cedar, a little smoke, something green you can't quite name."
- ✅ "Poured in Portland. Burned everywhere. Set accordingly."
- ❌ "Indulge in the luxurious self-care ritual of our artisanal soy candle collection."
- ❌ "Cozy season is HERE! Treat yourself to our curated fall collection!"

---

## Target Audience

Our core customer is someone we call **The Aesthetic Homebody** — a millennial or Gen Z buyer who treats their home like a creative project and shops with their eyes before their wallet.

They're on TikTok. They follow interior accounts on Instagram. They have opinions about throw pillows. And they're deeply skeptical of brands that try too hard.

What they need from us:
- Something that feels like it was made for someone like them
- Scents that are interesting — not safe
- Packaging that earns its place on their shelf
- A brand with actual personality behind it

Our secondary buyer — **The Gifter** — is shopping for someone else and needs the packaging and story to do the heavy lifting. They don't need to know much about candles. They just need to feel confident they're giving something good.

---

## Market Positioning

Wick & Wild sits between mass-market candle brands (generic, synthetic, soulless) and the ultra-premium end (beautiful but often cold and unapproachable).

We're the brand that figured out you can have great craft, genuine personality, beautiful packaging, and a price point that doesn't require a special occasion.

Our differentiation isn't the soy wax — everyone claims soy wax now. It's the scent storytelling, the brand voice, and the community we've built around a simple idea: your home should smell like the mood you're trying to create.

---

## Competitive Landscape

The candle market is enormous and crowded. Most players either go mass (Yankee, B&BW) or ultra-niche. Very few nail the middle ground of premium-but-accessible with genuine brand personality.

Boy Smells is the brand we watch most closely — they cracked voice and packaging in a way that's genuinely impressive. The difference: we're warmer, more accessible, and more community-forward.

We do not want to become Yankee Candle — ever. That comparison is the fastest way to misread us.

---

## Messaging

Everything starts with a simple truth: your home should smell like how you want to feel.

That's the whole brand. From there, we prove it through specificity — real scent descriptions, real batch sizes, real ingredients, real burn times. No vague claims, no wellness theater.

Our headline — *Set the mood.* — is a complete thought. It's permission. It's an invitation. And it works because we back it up.

---

## Sales Context

Wick & Wild is a high-emotion, low-consideration purchase. Nobody agonizes over buying a $32 candle. They hesitate for two reasons only: they can't smell it before they buy, and they're not sure it's worth it.

We solve both in the same session. The scent quiz handles the first. Burn time math and social proof handle the second.

The scent sampler pack is our most powerful sales tool — it converts first-timers into repeat buyers at a rate 3x higher than single-candle first purchases.

---

## Content Guidelines

Our content has one job: make someone feel something before they ever smell the candle.

We do that through scent storytelling, behind-the-scenes craft content, and a steady stream of real moments — real homes, real people, real Sunday mornings.

TikTok is our biggest discovery channel and gets the most raw, personality-forward content. Instagram is where the brand world lives. Email is where the relationship deepens.

The one rule that overrides everything else in content: we never make candles sound like a wellness assignment. We make them sound like a good idea.

---

## Customer Experience

Every interaction with Wick & Wild should feel like discovering something. A new scent, a new drop, a new reason to come back.

The experience starts with the scent quiz, continues through the unboxing (packaging is designed to feel like a gift), and deepens through post-purchase touchpoints that feel personal — never automated-feeling even when they are.

We measure experience by repeat purchase rate above everything else. If the candle was good and the experience was good, people come back. That's the whole model.

---

## Goals & KPIs

2026 is a growth year on every front — revenue, community, and physical retail presence.

The subscription candle club is the biggest new initiative: it extends LTV, creates predictable revenue, and deepens community engagement in a way single-purchase transactions never can.

The first wholesale doors are a brand play as much as a revenue play — being in the right boutiques signals legitimacy to a new audience.

---

## Constraints & No-Gos

We will never compromise the soy wax formula for cost. We will never fake urgency. We will never make the brand sound like a spa menu.

And if someone compares us to Yankee Candle, we take it as feedback that we have more work to do.
