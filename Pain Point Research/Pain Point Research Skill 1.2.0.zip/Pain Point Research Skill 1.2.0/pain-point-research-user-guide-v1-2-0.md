# Pain Point Research User Guide

## What This Guide Is For

This guide is the **easy version**. It is meant to help someone use the `pain-point-research` skill quickly without needing to read the entire skill package first. If the spec sheet defines the system and the master playbook explains the deeper operating logic, this guide shows how to get results fast.

## What The Skill Does

The skill helps turn a simple topic or product name into a **deeply researched, evidence-backed report on what real people hate, wish for, or struggle with**. It automatically searches Reddit, Trustpilot, Quora, and the open web for specific complaints, filters out the noise, and organizes the raw anger into actionable business insights.

| The skill gives you | Why it matters |
| --- | --- |
| Verbatim customer quotes | You can use real language in your marketing copy, not marketing speak |
| Source URLs | You can click through to read the full context of the complaint |
| Cross-validated themes | You can tell if a problem is real or just one angry person on Reddit |
| Severity scores | You know which problems are the most painful (and therefore the most profitable to solve) |

## What You Need To Provide

The skill requires only two things to work.

| Input | Best practice |
| --- | --- |
| Exa API Key | You need a free API key from [exa.ai](https://exa.ai) to power the searches |
| Topic | Keep it short (2-3 words). "Notion" or "candle business" works better than a long sentence |

## The Fastest Way To Use It

When you want a quick result, give your AI agent a short request like this:

> Do pain point research on Notion.

That is enough for the skill to run a standard-depth search across all four platforms and produce a strong, categorized report.

## What You Will Get Back

A normal output will include an executive summary and then several "Pain Point Cards."

| Section | Meaning |
| --- | --- |
| Executive summary | The top 5 themes in 1-2 sentences each |
| Pain point cards | The specific themes, ranked by severity and frequency |
| Verbatim quotes | 3-5 real quotes for each theme, with links to the original posts |
| One-line interpretation | Why this specific complaint matters to a business owner |
| Source coverage | A breakdown of where the complaints came from |
| Quote bank | A list of the 20-30 most punchy, copy-ready quotes for marketers |
| Surprising findings | Non-obvious patterns or contradictions the AI noticed in the data |

## How To Choose The Best Topic

The skill is smart enough to trim long, rambling topics down to their core words, but you will get the best results if you are specific from the start.

| If you want to research | Use a topic like this |
| --- | --- |
| A specific competitor | "Linear" or "Asana" |
| A broad category | "project management software" |
| A specific problem space | "freelance invoicing" |

If you are researching a word that has multiple meanings (like "Slack" the app vs. "slack" the noun), the AI agent will usually ask you to clarify before running the script.

## When To Stop And Be Careful

This skill is designed for qualitative research, not quantitative measurement.

| Warning sign | What to do |
| --- | --- |
| Single-source themes | If a complaint only appears on one subreddit, treat it as localized noise until you see it elsewhere |
| Low volume | If the skill returns very few complaints, try running it again with `--depth 3` or a broader topic |
| Positive sentiment | Don't use this skill to find out what people love about a product; it is specifically tuned to find pain |

## How To Go Deeper

If you want the skill to look harder, you can tell the AI agent to run a "deep scan."

> Do a deep dive on freelance invoicing pain points. Use depth 3.

This takes about two minutes instead of one, and generates 24 different search queries per platform instead of 16. It's the best way to research niche topics.

## Common Mistakes To Avoid

| Mistake | Better move |
| --- | --- |
| Passing a full sentence | Keep the topic to 2-3 words |
| Paraphrasing quotes | Never let the AI rewrite the quotes; the actual customer voice is the whole point |
| Ignoring the source URLs | Click the links to verify the context of the complaint |
| Using it for market sizing | Use it to understand *what* the problems are, not *how many* people have them |

## Best Practice For Busy Founders

If you are moving quickly, use this short checklist every time.

| Step | Action |
| --- | --- |
| 1 | Give the AI agent a 2-3 word topic |
| 2 | Read the executive summary |
| 3 | Skim the pain point cards |
| 4 | Save the quote bank for your marketing copy |
| 5 | Click the source URLs for the most surprising findings |

## If You Want More Control

If you want to go deeper, the rest of the documentation can help.

| Document | Use it for |
| --- | --- |
| `spec-sheet.md` | Understanding exactly what the skill is designed to do |
| `master-playbook.md` | Running the skill at a higher professional standard |
| `README.md` | Setting up the API key and troubleshooting errors |

## Bottom Line

The skill is at its best when you give it a **short, focused topic** and let it do the heavy lifting of finding and scoring the complaints. If you do that, it should give you a fast, credible, evidence-backed report that is much more useful than generic AI brainstorming.
