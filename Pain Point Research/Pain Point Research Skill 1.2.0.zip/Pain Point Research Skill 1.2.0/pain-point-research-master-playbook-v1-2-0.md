# Pain Point Research Master Playbook

## Playbook Purpose

This document is the **operating manual** for using the `pain-point-research` skill at a professional level. The spec sheet explains what the skill is. The user guide explains how to use it quickly. This playbook explains how to run it **well**, how to interpret the data consistently, and how to maintain quality when the results are messy.

## Operating Philosophy

The core idea behind this skill is simple: **generic AI brainstorming is a hallucination; authentic customer pain is reality.** The skill's job is not to invent problems, but to mechanically gather, score, and organize the problems that people are already screaming about on the internet.

The playbook assumes that high-quality research sits at the intersection of four forces.

| Force | Why it matters |
| --- | --- |
| Verifiability | Every claim must be backed by a verbatim quote and a source URL |
| Cross-validation | A theme is only credible if it appears across multiple independent sources |
| Linguistic severity | Not all complaints are equal; rage and abandonment words indicate higher priority |
| Actionable synthesis | A list of 200 raw quotes is useless without intelligent clustering |

## The Standard Workflow

Use the following workflow every time unless a strong reason exists to compress it.

| Step | Objective |
| --- | --- |
| 1. Normalize the topic | Trim the user's request down to a 2-3 word core noun phrase |
| 2. Generate queries | Create angle-specific searches (complaints, wishes, comparisons, questions) |
| 3. Fetch data | Run parallel searches across Reddit, Trustpilot, Quora, and the web via Exa |
| 4. Filter and score | Drop irrelevant results and score the rest for linguistic severity |
| 5. Deduplicate | Remove near-identical complaints |
| 6. Cluster themes | Group the top ~50 complaints into 8-15 specific, actionable categories |
| 7. Rank themes | Sort the clusters by frequency, source diversity, and average severity |
| 8. Render report | Present the findings in a clean, editorial-style document |

## Step 1: Normalize The Topic Correctly

Do not rush past the input step. Weak inputs create weak outputs. Search engines (and Exa's neural search) handle verbose, conversational queries poorly.

| Input | Normalized | Why it matters |
| --- | --- | --- |
| "small home-based candle business" | "candle business" | Long phrases dilute the search intent; core nouns concentrate it |
| "enterprise SaaS project management tool" | "project management tool" | Adjectives confuse keyword matchers |
| "Notion" | "Notion" | Short topics pass through unchanged |

If the topic is highly ambiguous (e.g., "Apple" the fruit vs. "Apple" the company), ask the user for clarification before running the script.

## Step 2: Generate Angle-Specific Queries

The single biggest lever for output quality is asking the right questions. Searching "Notion problems" is not enough. The skill generates queries across four distinct categories of pain.

| Category | Typical patterns | What it uncovers |
| --- | --- | --- |
| Complaint | "[topic] frustrating", "I hate [topic]" | Direct expressions of anger and technical failure |
| Wish | "wish [topic] had", "[topic] missing" | Unmet needs and feature requests |
| Comparison | "switched from [topic]", "[topic] vs" | Why customers churn to competitors |
| Question | "how to fix [topic]", "help with [topic]" | Confusion, poor UX, and onboarding friction |

## Step 3: Execute The Search (The Mechanical Layer)

The skill uses Python to execute the searches mechanically, bypassing the AI agent's context window limits and web browsing latency.

| Source | Role | Notes |
| --- | --- | --- |
| Reddit | Unfiltered community discourse | Routed through Exa to avoid IP blocks |
| Trustpilot | Post-purchase customer reviews | High concentration of fulfillment/billing complaints |
| Quora | Question-and-answer format | High concentration of comparison/alternative queries |
| Web | Blogs, niche forums, Substack | High concentration of long-form critiques and reviews |

If the script fails with an `EXA_API_KEY not set` error, stop immediately and ask the user to provide their key.

## Step 4: Score The Complaints With Judgment

The skill uses linguistic markers to score severity, not black-box sentiment analysis. This makes the scoring explainable and consistent.

| Marker category | Examples | Weight |
| --- | --- | --- |
| High-intensity rage | "fucking hate", "absolute trash", "rage quit" | +5 |
| Medium-intensity rage | "frustrating", "unusable", "nightmare" | +2 |
| Low-intensity rage | "bad", "buggy", "clunky" | +1 |
| Wish / Need | "dying for", "desperately need", "if only" | +2 to +4 |
| Abandonment | "switched from", "canceling", "alternative to" | +2 to +5 |

The script handles this automatically, but the agent must understand the logic to interpret the final `rank_score` correctly.

## Step 5: Cluster The Themes (The Intelligent Layer)

This is where the AI agent earns its keep. A list of 200 raw quotes is overwhelming. The agent must read the JSON output and group the complaints into specific, actionable themes.

| Theme name | Verdict | Why |
| --- | --- | --- |
| "Performance issues" | Bad | Too vague to act on |
| "Database queries crawl past 1000 rows" | Good | Specific, technical, and fixable |
| "UX problems" | Bad | Meaningless categorization |
| "Mobile editor loses cursor position" | Good | Replicable bug |

Themes should be specific enough that a product manager could imagine writing a Jira ticket for them, or a copywriter could imagine writing a headline against them.

## Step 6: Cross-Validate For Credibility

A theme that appears 50 times on a single subreddit might just be an organized complaint campaign. A theme that appears 5 times across Reddit, Trustpilot, and a personal blog is a structural truth.

| Source diversity | Interpretation |
| --- | --- |
| 1 source | Localized noise; treat with skepticism |
| 2 sources | Emerging pattern; worth noting |
| 3+ sources | Structural truth; high-confidence finding |

Always calculate and display the source diversity for each theme in the final report.

## Step 7: Render The Final Report

The final result should be easy to scan, highly readable, and editorial in style. Think like a busy founder reading a research brief.

| Formatting priority | Standard |
| --- | --- |
| Executive summary | Top 5 themes in 1-2 sentences each |
| Verbatim quotes | 3-5 per theme, with hyperlinked source URLs |
| Clean typography | Generous whitespace, clear headers, no dense walls of text |
| Quote bank | A dedicated section of 20-30 punchy quotes for marketers to lift |
| Surprising findings | Call out contradictions, non-obvious patterns, or pricing blind spots |

## Quality Control Checklist

Before finalizing any output, run this mental checklist.

| Check | Pass condition |
| --- | --- |
| Verifiability | Every quote is verbatim and has a source URL |
| Specificity | Theme names are actionable, not generic |
| Proportionality | The report reflects the actual severity scores in the data |
| Completeness | The source coverage breakdown is included |
| Safety | The agent did not hallucinate or paraphrase any quotes |

If any one of these fails, revise before presenting the answer.

## Failure Modes To Watch For

The most common quality breakdowns are predictable. Watch for them aggressively.

| Failure mode | Why it is dangerous |
| --- | --- |
| Paraphrasing quotes | Destroys the authenticity and voice-of-customer value |
| Generic theme naming | Renders the research unactionable |
| Ignoring source diversity | Elevates localized noise to structural truth |
| Treating the script as a black box | The agent must actively interpret the JSON, not just regurgitate it |

## Gold Standard Output

A gold-standard output does not just list complaints. It demonstrates judgment. It reads the data correctly, organizes it intelligently, preserves the raw human emotion of the quotes, and gives the user a clear map of where their product or category is failing.

| Gold standard trait | What it looks like |
| --- | --- |
| Specific | Names the real issue, not a vague category |
| Cross-validated | Proves the issue exists across multiple platforms |
| Authentic | Preserves the typos, anger, and exact phrasing of the user |
| Useful | A founder could build a roadmap or marketing campaign directly from it |

## Final Playbook Principle

The best research report is not the one with the most data. It is the one with the highest **signal-to-noise ratio**. In pain point research, synthesis beats volume every time.
