# Pain Point Research Spec Sheet

## Document Purpose

This document defines the **product specification** for the `pain-point-research` skill (v1.2.0). It explains what the skill is, what it is supposed to do, what inputs it expects, what outputs it must produce, and what guardrails determine acceptable performance.

The spec sheet is the authoritative build-level reference for the skill. It is not a quick-start guide and it is not the full operating playbook. It exists to define the system clearly enough that future revisions remain aligned with the original intent.

## Skill Identity

| Field | Specification |
| --- | --- |
| Skill name | `pain-point-research` |
| Version | 1.2.0 |
| Primary purpose | Surface and synthesize authentic customer complaints, wishes, and unmet needs from across the internet |
| Primary domain | Market research, startup validation, competitive intelligence, and copywriting |
| Primary output type | A structured, editorial-style research report with clustered themes and verbatim quotes |
| Data sources | Reddit, Trustpilot, Quora, and the open web (via Exa neural search) |

## Problem Statement

Founders, product managers, and marketers need to know what customers actually care about. Traditional market research is slow and expensive, while generic AI prompts (e.g., "What are the pain points of X?") produce hallucinated, generic bullet points that lack real-world evidence. This skill solves that problem by using Python to mechanically gather and score hundreds of authentic, verbatim complaints from across the internet, and then using the AI agent to synthesize those raw quotes into actionable, cross-validated themes.

## Core Objectives

| Objective | Meaning |
| --- | --- |
| Ground everything in evidence | Every theme must be backed by real, verbatim quotes with source URLs |
| Ask better questions | The skill must use specific pain-pattern queries (complaints, wishes, comparisons) rather than just searching the topic name |
| Filter the noise | The skill must programmatically filter out irrelevant results using linguistic severity markers (rage, wish, and abandonment words) |
| Cross-validate themes | A complaint that appears across multiple platforms (e.g., Reddit and Trustpilot) is more credible than a complaint isolated to one source |
| Deliver actionable synthesis | The final output must be clustered into specific, fixable themes, not a raw dump of 200 quotes |

## Supported Use Cases

This skill is designed for deep qualitative research into specific topics, products, or categories.

| Supported use case | Included |
| --- | --- |
| Startup idea validation | Yes |
| Product roadmap prioritization | Yes |
| Marketing copy generation (voice of customer) | Yes |
| Competitive intelligence | Yes |
| General category research | Yes |
| Positive sentiment analysis | No |
| Quantitative market sizing | No |
| Non-English research | No |

## Required Inputs

The skill requires a specific topic and one API credential.

| Input | Required status | Description |
| --- | --- | --- |
| Topic | Required | The product, category, or problem space to research (e.g., "Notion", "freelance invoicing", "candle business") |
| `EXA_API_KEY` | Required | An API key from exa.ai to power the neural search across all four sources |
| Depth | Optional | 1 (light), 2 (standard, default), or 3 (deep) |
| Sources | Optional | A comma-separated subset of `reddit,trustpilot,quora,web` |

## Functional Requirements

| Requirement ID | Requirement |
| --- | --- |
| FR-01 | The skill must normalize the user's topic label to its core 2-3 word noun phrase before generating queries |
| FR-02 | The skill must generate pain-pattern queries across four categories: complaints, wishes, comparisons, and questions |
| FR-03 | The skill must execute searches across Reddit, Trustpilot, Quora, and the open web using Exa's search API |
| FR-04 | The skill must send the `User-Agent: curl/7.88.1` header on all Exa requests to bypass Cloudflare 403 blocks |
| FR-05 | The skill must score each retrieved result for severity based on specific linguistic markers |
| FR-06 | The skill must deduplicate near-identical results using fuzzy fingerprinting |
| FR-07 | The skill must output a JSON file containing the ranked complaints, run metadata, and source coverage |
| FR-08 | The agent must read the JSON output and cluster the top ~50 complaints into 8-15 specific, actionable themes |
| FR-09 | The agent must render a final report that preserves verbatim quotes and source URLs |

## Non-Functional Requirements

| Requirement ID | Requirement |
| --- | --- |
| NFR-01 | The Python scripts must rely only on the standard library (no pip installs required) |
| NFR-02 | The Python scripts must execute in parallel threads to minimize latency |
| NFR-03 | The agent must never paraphrase or hallucinate quotes; verbatim text is sacred |
| NFR-04 | The final report must be highly readable, using an editorial style with clean typography and generous whitespace |

## Resource Architecture

The skill package is intentionally split between mechanical data gathering (Python) and intelligent synthesis (the agent).

| File | Role |
| --- | --- |
| `SKILL.md` | Core instructions for the agent, including how to run the scripts and how to synthesize the JSON output |
| `README.md` | Human-facing documentation, setup instructions, and troubleshooting |
| `scripts/run.py` | The main orchestrator and CLI entry point |
| `scripts/patterns.py` | Topic normalization and query expansion logic |
| `scripts/exa_fetch.py` | Data retrieval logic for all four sources via Exa |
| `scripts/analyze.py` | Severity scoring, deduplication, and ranking logic |

## Revision Standard

Future updates should preserve the following principles: zero external pip dependencies, single-credential architecture (Exa only), strict separation of mechanical gathering from agent synthesis, and absolute preservation of verbatim quotes and source URLs.
